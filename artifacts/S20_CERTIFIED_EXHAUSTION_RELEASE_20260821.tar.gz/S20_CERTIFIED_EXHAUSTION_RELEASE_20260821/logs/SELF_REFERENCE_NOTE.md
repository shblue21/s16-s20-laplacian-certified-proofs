# Replay-log and archive-hash note

A transcript of replaying an archive cannot be inserted into that same archive without changing the archive bytes and therefore its SHA-256. This release contains the successful preseal reproduction logs for the fixed proof payload. The final fresh-directory replay transcript, command-exit ledger, archive SHA-256 check, and final `tar -tzf` listing are distributed beside the archive. They replay the final archive after its hash is fixed.
