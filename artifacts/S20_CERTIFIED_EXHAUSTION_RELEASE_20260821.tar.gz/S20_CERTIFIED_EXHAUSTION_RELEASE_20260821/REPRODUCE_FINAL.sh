#!/usr/bin/env bash
set -u -o pipefail
export PYTHONDONTWRITEBYTECODE=1
printf '===== COMMAND: sha256sum -c MANIFEST.sha256 =====\n'
sha256sum -c MANIFEST.sha256
mrc=$?
printf '===== EXIT CODE: %d =====\n' "$mrc"
if [ "$mrc" -ne 0 ]; then
  echo '===== REPRODUCE_FINAL.sh RESULT: FAIL (manifest) =====' >&2
  exit "$mrc"
fi
printf '\n===== COMMAND: bash REPRODUCE.sh =====\n'
bash REPRODUCE.sh
rrc=$?
printf '===== EXIT CODE: %d =====\n' "$rrc"
if [ "$rrc" -eq 0 ]; then
  echo '===== REPRODUCE_FINAL.sh RESULT: PASS ====='
else
  echo "===== REPRODUCE_FINAL.sh RESULT: FAIL ($rrc) =====" >&2
fi
exit "$rrc"
