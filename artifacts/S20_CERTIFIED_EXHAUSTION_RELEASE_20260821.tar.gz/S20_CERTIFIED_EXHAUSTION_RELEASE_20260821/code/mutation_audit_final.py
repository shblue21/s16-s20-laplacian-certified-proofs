#!/usr/bin/env python3
"""Adversarial mutation tests for arithmetic, coverage, branching and release closure."""
from __future__ import annotations
import gzip
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('s20_verify_mutation_target',ROOT/'code/verify_certificates.py')
if spec is None or spec.loader is None:raise RuntimeError('cannot load verifier')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)

class MutationAuditError(RuntimeError):pass

def require(c,m):
    if not c:raise MutationAuditError(str(m))

def rejected(fn):
    try:fn()
    except Exception:return True
    return False

def read_pairs(name):
    out=[]
    with gzip.open(ROOT/'data'/name,'rt',encoding='ascii') as f:
        for line in f:
            a,b=line.rstrip().split('|');out.append((tuple(map(int,a.split())),int(b)))
    return out

def main():
    reps=read_pairs('complement_representatives.txt.gz')
    summary=json.loads((ROOT/'certs/stage1_summary.json').read_text())
    with gzip.open(ROOT/'certs'/summary['shards'][0],'rt',encoding='utf-8') as f:obj=json.load(f)
    idx,cert=obj['records'][0];seq,t=reps[idx];model=v.stage_model(seq,False)
    require(cert,'first certificate empty')
    negated=[[i,-a] for i,a in cert]
    arithmetic_rejected=rejected(lambda:v.check_sparse_certificate(model,negated,'negated mutation'))
    empty_rejected=rejected(lambda:v.check_sparse_certificate(model,[],'empty mutation'))
    require(arithmetic_rejected and empty_rejected,'arithmetic mutation accepted')

    survivor_set=set(read_pairs('stage1_survivors.txt.gz'))
    expected=[i for i,x in enumerate(reps) if x not in survivor_set]
    dropped=expected[1:]
    coverage_rejected=rejected(lambda:v.require(dropped==expected,'missing leaf mutation'))
    require(coverage_rejected,'missing-leaf mutation accepted')

    roots=json.loads((ROOT/'data/final_integer_roots.json').read_text())['roots']
    r=roots[0];cm=v.class_model(tuple(r['sequence']),int(r['triangles']))
    bad_index=0
    require(bad_index not in cm.integer,'chosen mutation variable unexpectedly integer')
    branch_rejected=rejected(lambda:v.require(bad_index in cm.integer,'branch variable is not integer-constrained'))
    require(branch_rejected,'noninteger branch mutation accepted')

    probe=ROOT/'code/unexpected_mutation_probe.py'
    require(not probe.exists(),'probe pre-exists')
    try:
        probe.write_text('raise SystemExit(99)\n',encoding='utf-8')
        unexpected_file_rejected=rejected(v.audit_release_files)
    finally:
        probe.unlink(missing_ok=True)
    require(unexpected_file_rejected,'unexpected Python file accepted')

    result={'status':'MUTATION_AUDIT_PASS','negated_certificate_rejected':arithmetic_rejected,'empty_certificate_rejected':empty_rejected,'missing_leaf_rejected':coverage_rejected,'noninteger_branch_rejected':branch_rejected,'unexpected_python_rejected':unexpected_file_rejected}
    print(json.dumps(result,sort_keys=True));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        print(json.dumps({'status':'MUTATION_AUDIT_FAILED','error':str(e)},sort_keys=True),file=sys.stderr);raise SystemExit(2)
