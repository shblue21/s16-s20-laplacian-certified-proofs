#!/usr/bin/env python3
"""Strict standard-library verifier for the n=20 consecutive Laplacian certificate.

The verifier does not trust serialized constraint matrices.  For every leaf it
reconstructs the relevant n=20 linear relaxation from the degree sequence and
the mathematical definitions.  Each stored sparse integer vector z certifies
infeasibility of a standard-form system B w = h, w >= 0 by

    B^T z >= 0  and  h^T z < 0.

All checks use Python integers.  Explicit exceptions, not ``assert``, are used,
so verification remains active under ``python -O``.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations_with_replacement
from pathlib import Path
import gzip
import hashlib
import json
import math
import os
import stat
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CERTS = ROOT / "certs"
N = 20
K = range(1, 20)
EXPECTED_PYTHON = {
    "code/verify_certificates.py",
    "code/generate_certificates.py",
    "code/generator_models.py",
    "code/independent_enumeration_audit.py",
    "code/audit_graph_identities.py",
    "code/mutation_audit_final.py",
}


class VerificationError(RuntimeError):
    pass


def require(condition: bool, message: object) -> None:
    if not condition:
        raise VerificationError(str(message))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def audit_release_files() -> dict[str, object]:
    manifest_path = ROOT / "MANIFEST.sha256"
    require(manifest_path.is_file(), "MANIFEST.sha256 is missing")
    records: dict[str, str] = {}
    for lineno, line in enumerate(manifest_path.read_text(encoding="utf-8").splitlines(), 1):
        require(len(line) >= 67 and line[64:66] == "  ", f"bad manifest line {lineno}")
        digest, rel = line[:64], line[66:]
        require(all(c in "0123456789abcdef" for c in digest), f"bad SHA-256 at manifest line {lineno}")
        require(rel and rel not in records, f"duplicate/empty manifest path at line {lineno}: {rel!r}")
        require(not rel.startswith("/") and ".." not in Path(rel).parts, f"unsafe manifest path: {rel}")
        records[rel] = digest
    actual: set[str] = set()
    for p in ROOT.rglob("*"):
        if p.is_symlink():
            raise VerificationError(f"symlink is not permitted in release: {p.relative_to(ROOT)}")
        if p.is_file():
            rel = p.relative_to(ROOT).as_posix()
            if rel != "MANIFEST.sha256":
                actual.add(rel)
    require(actual == set(records), {
        "manifest_missing_files": sorted(actual - set(records)),
        "manifest_lists_absent_files": sorted(set(records) - actual),
    })
    for rel, expected in records.items():
        got = sha256_file(ROOT / rel)
        require(got == expected, f"manifest hash mismatch for {rel}: {got} != {expected}")
    py = {x for x in actual if x.endswith(".py")}
    require(py == EXPECTED_PYTHON, {"unexpected_python": sorted(py - EXPECTED_PYTHON), "missing_python": sorted(EXPECTED_PYTHON - py)})
    required = {
        "REPRODUCE.sh", "REPRODUCE_FINAL.sh", "PARAMS.json", "REPORT.md",
        "RESULT_SUMMARY.json", "ENVIRONMENT.txt", "certs/SUMMARY.json",
    }
    require(required <= actual, f"required release files absent: {sorted(required - actual)}")
    # Reject accidentally substituted n=16 verification code by characteristic literals.
    verifier_text = (ROOT / "code/verify_certificates.py").read_text(encoding="utf-8")
    forbidden_markers = (
        "S_{" + str(16) + "," + str(16) + "}",
        "range(1, " + str(16) + ")",
        str(11000 + 40),
        "sum " + str(120),
        "spectrum 0,...," + str(15),
    )
    for forbidden in forbidden_markers:
        require(forbidden not in verifier_text, f"n=16 verifier residue detected: {forbidden!r}")
    return {"manifest_entries": len(records), "python_files": sorted(py)}


def verify_params() -> dict[str, int]:
    p = json.loads((ROOT / "PARAMS.json").read_text(encoding="utf-8"))
    spectrum = list(range(N))
    trace1 = sum(spectrum)
    trace2 = sum(k * k for k in spectrum)
    trace3 = sum(k ** 3 for k in spectrum)
    trace4 = sum(k ** 4 for k in spectrum)
    degree_square_sum = trace2 - trace1
    triangle_offset = trace3 - 3 * degree_square_sum
    tree_count = math.factorial(19) // 20
    expected = {
        "n": 20,
        "spectrum": spectrum,
        "edge_count": 95,
        "degree_sum": 190,
        "degree_square_sum": 2280,
        "triangle_offset": 29260,
        "trace_L4": 562666,
        "spanning_tree_count": 6082255020441600,
        "degree_min": 2,
        "degree_max": 17,
        "triangle_min": 127,
        "triangle_max": 348,
        "triangle_complement_total": 475,
    }
    require(p == expected, f"PARAMS.json mismatch: {p!r}")
    require(trace1 == 190 and trace1 % 2 == 0 and trace1 // 2 == 95, "trace/edge derivation failed")
    require(trace2 == 2470 and degree_square_sum == 2280, "second-moment derivation failed")
    require(trace3 == 36100 and triangle_offset == 29260, "third-moment derivation failed")
    require(trace4 == 562666, "fourth-moment derivation failed")
    require(tree_count == 6082255020441600, "Matrix-Tree value failed")
    return {"trace1": trace1, "trace2": trace2, "trace3": trace3, "trace4": trace4}


@dataclass
class Model:
    names: list[tuple]
    eq: list[tuple[dict[int, int], int]]
    ub: list[tuple[dict[int, int], int]]
    lo: list[int]
    hi: list[int | None]
    integer: set[int]

    def standard_rows(self) -> tuple[list[dict[int, int]], list[int], list[str]]:
        require(len(self.names) == len(self.lo) == len(self.hi), "model bound dimension mismatch")
        require(all(isinstance(x, int) for x in self.lo), "all lower bounds must be finite integers")
        rows: list[dict[int, int]] = []
        rhs: list[int] = []
        kinds: list[str] = []
        for row, b in self.eq:
            rows.append(row)
            rhs.append(b - sum(a * self.lo[j] for j, a in row.items()))
            kinds.append("eq")
        for row, b in self.ub:
            rows.append(row)
            rhs.append(b - sum(a * self.lo[j] for j, a in row.items()))
            kinds.append("ub")
        for j, u in enumerate(self.hi):
            if u is not None:
                require(self.lo[j] <= u, f"inconsistent bounds for {self.names[j]}: {self.lo[j]}>{u}")
                rows.append({j: 1})
                rhs.append(u - self.lo[j])
                kinds.append("upper")
        return rows, rhs, kinds


def add(row: dict[int, int], j: int, a: int) -> None:
    if a:
        row[j] = row.get(j, 0) + a
        if row[j] == 0:
            del row[j]


def stage_model(seq: tuple[int, ...], third: bool) -> Model:
    require(len(seq) == 20 and tuple(sorted(seq)) == seq, f"bad degree sequence: {seq}")
    require(all(2 <= d <= 17 for d in seq), f"degree outside proved range: {seq}")
    cnt = Counter(seq)
    ds = sorted(cnt)
    names: list[tuple] = []
    Y: dict[tuple[int, int], int] = {}
    for d in ds:
        for k in K:
            Y[d, k] = len(names)
            names.append(("Y", d, k))
    S: dict[int, int] = {}
    if third:
        for d in ds:
            S[d] = len(names)
            names.append(("S", d))
    eq: list[tuple[dict[int, int], int]] = []
    ub: list[tuple[dict[int, int], int]] = []
    for d in ds:
        m = cnt[d]
        eq.append(({Y[d, k]: 1 for k in K}, 19 * m))
        eq.append(({Y[d, k]: k for k in K}, 20 * m * d))
        eq.append(({Y[d, k]: k * k for k in K}, 20 * m * (d * d + d)))
    for k in K:
        eq.append(({Y[d, k]: 1 for d in ds}, 20))
    lo = [0] * len(names)
    hi: list[int | None] = [None] * len(names)
    if third:
        for d in ds:
            m = cnt[d]
            b0 = d ** 3 + 2 * d * d
            y3 = {Y[d, k]: k ** 3 for k in K}
            j = S[d]
            rest = list(seq)
            rest.remove(d)
            rest.sort()
            lo[j] = m * sum(rest[:d])
            hi[j] = m * sum(rest[-d:])
            ub.append(({q: -a for q, a in y3.items()}, -20 * m * (b0 + d)))
            ub.append((dict(y3), 20 * m * (b0 + d * (20 - d))))
            r = dict(y3); r[j] = -20; ub.append((r, 20 * m * b0))
            r = {q: -a for q, a in y3.items()}; r[j] = 20
            ub.append((r, 40 * m * math.comb(d, 2) - 20 * m * b0))
            R = 190 - 2 * math.comb(19 - d, 2)
            r = {q: -a for q, a in y3.items()}; r[j] = -20
            ub.append((r, -20 * m * (R + b0)))
            r = dict(y3); r[j] = 20; ub.append((r, 20 * m * (190 + b0)))
        eq.append(({S[d]: 1 for d in ds}, 2280))
    return Model(names, eq, ub, lo, hi, set())


def triple_capacity(z: tuple[int, int, int], cnt: Counter) -> int:
    cc = Counter(z)
    p = 1
    for d, r in cc.items():
        if r > cnt[d]:
            return 0
        p *= math.comb(cnt[d], r)
    return p


def class_model(seq: tuple[int, ...], triangles: int) -> Model:
    cnt = Counter(seq)
    ds = sorted(cnt)
    names: list[tuple] = []
    Y: dict[tuple[int, int], int] = {}
    for d in ds:
        for k in K:
            Y[d, k] = len(names); names.append(("Y", d, k))
    pairs = [(a, b) for i, a in enumerate(ds) for b in ds[i:]]
    E: dict[tuple[int, int], int] = {}
    for pair in pairs:
        E[pair] = len(names); names.append(("E",) + pair)
    triples = [z for z in combinations_with_replacement(ds, 3) if triple_capacity(z, cnt)]
    T: dict[tuple[int, int, int], int] = {}
    C: dict[tuple[int, int, int], int] = {}
    for z in triples:
        T[z] = len(names); names.append(("T",) + z)
    for z in triples:
        C[z] = len(names); names.append(("C",) + z)
    eq: list[tuple[dict[int, int], int]] = []
    ub: list[tuple[dict[int, int], int]] = []
    for d in ds:
        m = cnt[d]
        eq.append(({Y[d, k]: 1 for k in K}, 19 * m))
        eq.append(({Y[d, k]: k for k in K}, 20 * m * d))
        eq.append(({Y[d, k]: k * k for k in K}, 20 * m * (d * d + d)))
    for k in K:
        eq.append(({Y[d, k]: 1 for d in ds}, 20))
    for d in ds:
        r: dict[int, int] = {}
        for a, b in pairs:
            if a == b == d:
                add(r, E[a, b], 2)
            elif a == d or b == d:
                add(r, E[a, b], 1)
        eq.append((r, cnt[d] * d))
    eq.append(({T[z]: 1 for z in triples}, triangles))
    eq.append(({C[z]: 1 for z in triples}, 475 - triangles))
    for d in ds:
        m = cnt[d]; b0 = d ** 3 + 2 * d * d
        r = {Y[d, k]: k ** 3 for k in K}
        for a, b in pairs:
            q = 2 * d if a == b == d else (b if a == d else (a if b == d else 0))
            if q: add(r, E[a, b], -20 * q)
        for z in triples:
            q = z.count(d)
            if q: add(r, T[z], 40 * q)
        eq.append((r, 20 * m * b0))
    for d in ds:
        m = cnt[d]; db = 19 - d; b0 = db ** 3 + 2 * db * db
        r = {Y[d, 20 - k]: k ** 3 for k in K}
        const = 0
        for a, b in pairs:
            cap = math.comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
            q = 2 * (19 - d) if a == b == d else ((19 - b) if a == d else ((19 - a) if b == d else 0))
            if q:
                const += q * cap; add(r, E[a, b], 20 * q)
        for z in triples:
            q = z.count(d)
            if q: add(r, C[z], 40 * q)
        eq.append((r, 20 * m * b0 + 20 * const))
    for a, b in pairs:
        cap = math.comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
        rg: dict[int, int] = {}; rc: dict[int, int] = {}
        for z in triples:
            cc = Counter(z)
            q = math.comb(cc[a], 2) if a == b else cc[a] * cc[b]
            if q:
                add(rg, T[z], q); add(rc, C[z], q)
        add(rg, E[a, b], -(min(a, b) - 1)); ub.append((rg, 0))
        q = 18 - max(a, b); add(rc, E[a, b], q); ub.append((rc, q * cap))
    for d in ds:
        rg: dict[int, int] = {}; rc: dict[int, int] = {}
        for z in triples:
            q = z.count(d)
            if q:
                add(rg, T[z], q); add(rc, C[z], q)
        ub.append((rg, cnt[d] * math.comb(d, 2)))
        ub.append((rc, cnt[d] * math.comb(19 - d, 2)))
    lo = [0] * len(names)
    hi: list[int | None] = [None] * len(names)
    integer: set[int] = set()
    for a, b in pairs:
        j = E[a, b]
        hi[j] = math.comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
        integer.add(j)
    for z in triples:
        cap = triple_capacity(z, cnt)
        for D in (T, C):
            j = D[z]; hi[j] = cap; integer.add(j)
    return Model(names, eq, ub, lo, hi, integer)


def branch_model(model: Model, j: int, floor: int, left: bool) -> Model:
    lo = list(model.lo); hi = list(model.hi)
    if left:
        hi[j] = floor if hi[j] is None else min(hi[j], floor)
    else:
        lo[j] = max(lo[j], floor + 1)
    return Model(model.names, model.eq, model.ub, lo, hi, model.integer)


def check_sparse_certificate(model: Model, cert: object, label: str = "") -> int:
    require(isinstance(cert, list), f"{label}: certificate is not a list")
    rows, rhs, kinds = model.standard_rows()
    z: dict[int, int] = {}
    previous = -1
    for item in cert:
        require(isinstance(item, list) and len(item) == 2, f"{label}: malformed sparse multiplier {item!r}")
        i, a = item
        require(type(i) is int and type(a) is int, f"{label}: multiplier index/coefficient must be integers")
        require(previous < i < len(rows), f"{label}: multiplier indices must be strictly increasing and in range: {i}")
        require(a != 0, f"{label}: zero coefficient must not be serialized")
        previous = i; z[i] = a
    lhs = [0] * len(model.names)
    total = 0
    for i, a in z.items():
        total += a * rhs[i]
        for j, c in rows[i].items():
            lhs[j] += a * c
        if kinds[i] != "eq":
            require(a >= 0, f"{label}: negative multiplier on {kinds[i]} slack row {i}: {a}")
    bad = next(((j, a, model.names[j]) for j, a in enumerate(lhs) if a < 0), None)
    require(bad is None, f"{label}: B^T z has a negative original-variable column: {bad}")
    require(total < 0, f"{label}: h^T z is not negative: {total}")
    return total


def read_gzip_bytes(path: Path) -> bytes:
    with gzip.open(path, "rb") as f:
        return f.read()


def parse_seq_lines(data: bytes, pair: bool) -> list:
    out = []
    for raw in data.decode("ascii").splitlines():
        if pair:
            a, b = raw.split("|")
            out.append((tuple(map(int, a.split())), int(b)))
        else:
            out.append(tuple(map(int, raw.split())))
    return out


def seq_bytes(items: list, pair: bool) -> bytes:
    if pair:
        return "".join(" ".join(map(str, s)) + "|" + str(t) + "\n" for s, t in items).encode("ascii")
    return "".join(" ".join(map(str, s)) + "\n" for s in items).encode("ascii")


@lru_cache(None)
def feasible_mult(d: int, n: int, s: int, q: int) -> bool:
    if n < 0:
        return False
    if d > 17:
        return n == s == q == 0
    if n == 0:
        return s == q == 0
    if s < d * n or s > 17 * n or q < d * d * n or q > 17 * 17 * n:
        return False
    if q * n < s * s:
        return False
    if d == 17:
        return s == d * n and q == d * d * n
    return any(feasible_mult(d + 1, n - c, s - c * d, q - c * d * d) for c in range(n + 1))


def enumerate_moment_sequences() -> list[tuple[int, ...]]:
    cnt = [0] * 18
    out: list[tuple[int, ...]] = []
    def rec(d: int, n: int, s: int, q: int) -> None:
        if d > 17:
            if n == s == q == 0:
                out.append(tuple(x for x in range(2, 18) for _ in range(cnt[x])))
            return
        if not feasible_mult(d, n, s, q):
            return
        if d == 17:
            cnt[d] = n
            out.append(tuple(x for x in range(2, 18) for _ in range(cnt[x])))
            cnt[d] = 0
            return
        for c in range(n + 1):
            if feasible_mult(d + 1, n - c, s - c * d, q - c * d * d):
                cnt[d] = c
                rec(d + 1, n - c, s - c * d, q - c * d * d)
        cnt[d] = 0
    rec(2, 20, 190, 2280)
    out.sort()
    return out


def erdos_gallai(seq: tuple[int, ...]) -> bool:
    d = list(reversed(seq))
    prefix = 0
    for k in range(1, 21):
        prefix += d[k - 1]
        rhs = k * (k - 1) + sum(min(x, k) for x in d[k:])
        if prefix > rhs:
            return False
    return True


def verify_coverage() -> tuple[list, list, dict[str, object]]:
    coverage = json.loads((DATA / "coverage.json").read_text(encoding="utf-8"))
    require(coverage.get("format") == "s20-coverage-v1", "bad coverage format")
    raw: dict[str, bytes] = {}
    parsed: dict[str, list] = {}
    pair_names = {
        "base_sequences.txt.gz", "complement_representatives.txt.gz",
        "stage1_source.txt.gz", "stage1_survivors.txt.gz",
        "stage2_source.txt.gz", "stage2_survivors.txt.gz",
        "class_source.txt.gz", "class_survivors.txt.gz",
    }
    for name, meta in coverage["files"].items():
        path = DATA / name
        require(path.is_file(), f"coverage file missing: {name}")
        require(sha256_file(path) == meta["sha256_compressed"], f"compressed coverage hash mismatch: {name}")
        data = read_gzip_bytes(path)
        require(len(data) == meta["uncompressed_bytes"], f"uncompressed size mismatch: {name}")
        require(sha256_bytes(data) == meta["sha256_uncompressed"], f"uncompressed coverage hash mismatch: {name}")
        require(data.count(b"\n") == meta["count"], f"line count mismatch: {name}")
        raw[name] = data
        if name != "complement_pairs.txt.gz":
            parsed[name] = parse_seq_lines(data, name in pair_names)
    moment = enumerate_moment_sequences()
    require(len(moment) == 209932, f"moment sequence count {len(moment)}")
    require(seq_bytes(moment, False) == raw["moment_sequences.txt.gz"], "moment source list mismatch")
    graphical = [s for s in moment if erdos_gallai(s)]
    require(len(graphical) == 200108, f"graphical sequence count {len(graphical)}")
    require(seq_bytes(graphical, False) == raw["graphical_sequences.txt.gz"], "graphical source list mismatch")
    base = []
    for s in graphical:
        q = sum(d ** 3 for d in s) - 29260
        if q % 6 == 0:
            t = q // 6
            if 127 <= t <= 348:
                base.append((s, t))
    base.sort()
    require(len(base) == 160244, f"base sequence count {len(base)}")
    require(seq_bytes(base, True) == raw["base_sequences.txt.gz"], "base source list mismatch")
    baseset = set(base)
    reps = []
    fixed = []
    expected_pair_lines = []
    seen = set()
    for item in base:
        if item in seen:
            continue
        s, t = item
        mate = (tuple(sorted(19 - d for d in s)), 475 - t)
        require(mate in baseset, f"complement mate absent: {item} -> {mate}")
        if mate == item:
            fixed.append(item)
        rep = min(item, mate)
        reps.append(rep)
        seen.add(item); seen.add(mate)
        expected_pair_lines.append(" ".join(map(str, rep[0])) + "|" + str(rep[1]) + "||" + " ".join(map(str, max(item, mate)[0])) + "|" + str(max(item, mate)[1]) + "\n")
    reps.sort()
    # Rebuild pair lines in representative order, independent of base traversal order.
    expected_pair_lines = []
    for s, t in reps:
        mate = (tuple(sorted(19 - d for d in s)), 475 - t)
        require((s, t) < mate, f"complement canonical representative not strict: {(s,t)}")
        expected_pair_lines.append(" ".join(map(str, s)) + "|" + str(t) + "||" + " ".join(map(str, mate[0])) + "|" + str(mate[1]) + "\n")
    require(len(fixed) == 0, f"unexpected complement fixed points: {fixed[:3]}")
    require(len(reps) == 80122, f"complement representative count {len(reps)}")
    require(seq_bytes(reps, True) == raw["complement_representatives.txt.gz"], "representative list mismatch")
    require("".join(expected_pair_lines).encode("ascii") == raw["complement_pairs.txt.gz"], "complement pair coverage mismatch")
    require(raw["stage1_source.txt.gz"] == raw["complement_representatives.txt.gz"], "Stage 1 source alias mismatch")
    require(raw["stage2_source.txt.gz"] == raw["stage1_survivors.txt.gz"], "Stage 2 source alias mismatch")
    require(raw["class_source.txt.gz"] == raw["stage2_survivors.txt.gz"], "class source alias mismatch")
    mapping = coverage.get("source_survivor_sha256")
    expected_mapping = {
        "stage1_source": sha256_bytes(raw["stage1_source.txt.gz"]),
        "stage1_survivor": sha256_bytes(raw["stage1_survivors.txt.gz"]),
        "stage2_source": sha256_bytes(raw["stage2_source.txt.gz"]),
        "stage2_survivor": sha256_bytes(raw["stage2_survivors.txt.gz"]),
        "class_source": sha256_bytes(raw["class_source.txt.gz"]),
        "class_survivor": sha256_bytes(raw["class_survivors.txt.gz"]),
    }
    require(mapping == expected_mapping, f"source/survivor SHA-256 ledger mismatch: {mapping}")
    s1 = parsed["stage1_survivors.txt.gz"]
    s2 = parsed["stage2_survivors.txt.gz"]
    class_survivors = parsed["class_survivors.txt.gz"]
    roots_json = json.loads((DATA / "final_integer_roots.json").read_text(encoding="utf-8"))["roots"]
    roots_from_json = [(tuple(r["sequence"]), int(r["triangles"])) for r in roots_json]
    require(class_survivors == roots_from_json, "class survivor list and root metadata disagree")
    require(len(s1) == 16887 and len(set(s1)) == len(s1), "Stage 1 survivor count/uniqueness")
    require(len(s2) == 345 and len(set(s2)) == len(s2), "Stage 2 survivor count/uniqueness")
    require(set(s1) <= set(reps), "Stage 1 survivor outside source")
    require(set(s2) <= set(s1), "Stage 2 survivor outside source")
    require(s1 == [x for x in reps if x in set(s1)], "Stage 1 survivor order is not source order")
    require(s2 == [x for x in s1 if x in set(s2)], "Stage 2 survivor order is not source order")
    counts = coverage["counts"]
    expected_counts = {
        "moment": 209932, "graphical": 200108, "base": 160244,
        "complement_representatives": 80122, "complement_fixed_points": 0,
        "stage1_source": 80122, "stage1_survivors": 16887, "stage1_leaves": 63235,
        "stage2_source": 16887, "stage2_survivors": 345, "stage2_leaves": 16542,
        "class_source": 345, "class_roots": 2, "class_root_leaves": 343,
        "branch_roots": 2, "branch_leaves": 4, "total_leaves": 80124,
    }
    require(counts == expected_counts, f"coverage counts mismatch: {counts}")
    return reps, s1, {"stage2": s2, "coverage": coverage, "counts": counts}


def load_cert_shard(path: Path, stage: str) -> list:
    with gzip.open(path, "rt", encoding="utf-8") as f:
        obj = json.load(f)
    require(obj.get("format") == "s20-standard-form-farkas-z-v1", f"bad certificate format: {path.name}")
    require(obj.get("stage") == stage, f"stage label mismatch in {path.name}")
    require(isinstance(obj.get("records"), list), f"missing records in {path.name}")
    return obj["records"]


def verify_stage(stage: str, source: list, survivors: list, model_builder) -> dict[str, int]:
    summary = json.loads((CERTS / f"{stage}_summary.json").read_text(encoding="utf-8"))
    master = json.loads((CERTS / "SUMMARY.json").read_text(encoding="utf-8"))[stage]
    require(summary == master, f"{stage} summary differs from master summary")
    require(summary["source_count"] == len(source), f"{stage} source count")
    require(summary["survivor_count"] == len(survivors), f"{stage} survivor count")
    survivor_set = set(survivors)
    expected = [i for i, item in enumerate(source) if item not in survivor_set]
    require(len(expected) == summary["leaf_count"], f"{stage} expected leaf count")
    seen: list[int] = []
    support_sum = 0
    support_min = None
    support_max = 0
    for shard_name in summary["shards"]:
        require(Path(shard_name).name == shard_name, f"unsafe shard name: {shard_name}")
        path = CERTS / shard_name
        require(path.is_file(), f"missing shard: {shard_name}")
        for record in load_cert_shard(path, stage):
            require(isinstance(record, list) and len(record) == 2, f"bad {stage} record")
            idx, cert = record
            require(type(idx) is int and 0 <= idx < len(source), f"bad {stage} source index: {idx}")
            require(not seen or idx > seen[-1], f"{stage} indices not globally strictly increasing: {idx}")
            seq, t = source[idx]
            model = model_builder(seq, t)
            check_sparse_certificate(model, cert, f"{stage}[{idx}]")
            n = len(cert); support_sum += n; support_max = max(support_max, n); support_min = n if support_min is None else min(support_min, n)
            seen.append(idx)
    require(seen == expected, f"{stage} leaf coverage mismatch: got {len(seen)}, expected {len(expected)}")
    require(support_sum == summary["support_sum"], f"{stage} support sum mismatch")
    require(support_min == summary["support_min"] and support_max == summary["support_max"], f"{stage} support range mismatch")
    return {"source": len(source), "survivors": len(survivors), "leaves": len(seen), "support_sum": support_sum}


def verify_class_and_branches(source: list) -> dict[str, object]:
    roots_meta = json.loads((DATA / "final_integer_roots.json").read_text(encoding="utf-8"))
    require(roots_meta.get("format") == "s20-final-integer-roots-v1", "bad final roots format")
    roots = [(tuple(r["sequence"]), int(r["triangles"])) for r in roots_meta["roots"]]
    require(len(roots) == 2 and len(set(roots)) == 2 and set(roots) <= set(source), "bad final root list")
    require(roots == [x for x in source if x in set(roots)], "final roots are not in source order")
    class_result = verify_stage("class", source, roots, lambda s, t: class_model(s, t))
    with gzip.open(CERTS / "branch_leaves.json.gz", "rt", encoding="utf-8") as f:
        obj = json.load(f)
    require(obj.get("format") == "s20-branch-farkas-v1" and obj.get("leaf_count") == 4, "bad branch payload header")
    items = obj.get("roots")
    require(isinstance(items, list) and len(items) == 2, "branch root payload count")
    leaf_count = 0
    for expected_meta, item, root in zip(roots_meta["roots"], items, roots):
        require(item["root_index"] == expected_meta["root_index"], "branch root index mismatch")
        require((tuple(item["sequence"]), int(item["triangles"])) == root, "branch sequence mismatch")
        j = item["variable_index"]; floor = item["floor"]
        require(type(j) is int and type(floor) is int, "branch variable/floor must be integers")
        require(item["variable_name"] == expected_meta["branch_variable_name"], "branch variable metadata mismatch")
        require(j == expected_meta["branch_variable_index"] and floor == expected_meta["floor"], "branch metadata disagreement")
        model = class_model(*root)
        require(j in model.integer, f"branch variable is not integer-constrained: {j}")
        require(list(model.names[j]) == item["variable_name"], "branch variable name/index mismatch")
        require(model.lo[j] <= floor and (model.hi[j] is None or floor < model.hi[j]), "branch split does not cut parent integer interval")
        # For an integer x_j, x_j <= floor and x_j >= floor+1 are disjoint and exhaustive.
        left = branch_model(model, j, floor, True)
        right = branch_model(model, j, floor, False)
        require(left.hi[j] == floor and right.lo[j] == floor + 1, "branch child bounds are not exhaustive adjacent integer halves")
        check_sparse_certificate(left, item["left_cert"], f"branch[{item['root_index']}].left")
        check_sparse_certificate(right, item["right_cert"], f"branch[{item['root_index']}].right")
        leaf_count += 2
    require(leaf_count == 4, "branch leaf count")
    return {"class": class_result, "branch_roots": 2, "branch_leaves": leaf_count, "roots": roots_meta["roots"]}


def verify() -> dict[str, object]:
    started = time.time()
    files = audit_release_files()
    traces = verify_params()
    reps, s1, aux = verify_coverage()
    s2 = aux["stage2"]
    stage1 = verify_stage("stage1", reps, s1, lambda s, t: stage_model(s, False))
    stage2 = verify_stage("stage2", s1, s2, lambda s, t: stage_model(s, True))
    final = verify_class_and_branches(s2)
    master = json.loads((CERTS / "SUMMARY.json").read_text(encoding="utf-8"))
    total = stage1["leaves"] + stage2["leaves"] + final["class"]["leaves"] + final["branch_leaves"]
    require(master.get("format") == "s20-certificate-generation-summary-v1", "bad master certificate summary format")
    require(master.get("total_leaf_count") == total == 80124, f"total leaf count {total}")
    result = {
        "status": "VERIFIED_UNSAT",
        "n": 20,
        "spectrum": list(range(20)),
        "moment_sequences": 209932,
        "graphical_sequences": 200108,
        "base_sequences": 160244,
        "complement_representatives": 80122,
        "stage1": stage1,
        "stage2": stage2,
        "class_and_branch": final,
        "total_farkas_leaves": total,
        "uncovered": 0,
        "timeouts": 0,
        "unknown": 0,
        "crashes": 0,
        "release_files": files,
        "traces": traces,
        "elapsed_seconds": round(time.time() - started, 6),
    }
    return result


def main() -> int:
    try:
        print(json.dumps(verify(), sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "VERIFICATION_FAILED", "error": str(exc)}, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
