#!/usr/bin/env python3
"""Regenerate the complete n=20 Farkas/branch payload.

Generation is untrusted and requires NumPy, SciPy/HiGHS and SymPy.  The output
must be accepted by the separate standard-library verifier before use.
By default this script writes to ``regenerated_certs`` and never overwrites the
sealed ``certs`` directory.
"""
from __future__ import annotations
import argparse
import gzip
import json
import os
import shutil
import sys
import time
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from generator_models import stage_model, class_model, find_farkas, exact_check_z, apply_upper_branch  # noqa:E402


def read_pairs(name: str):
    with gzip.open(ROOT / "data" / name, "rt", encoding="ascii") as f:
        out=[]
        for line in f:
            a,b=line.rstrip("\n").split("|")
            out.append((tuple(map(int,a.split())),int(b)))
        return out


def write_gzip_json(path: Path, obj) -> None:
    data=(json.dumps(obj,separators=(",",":"),sort_keys=True)+"\n").encode()
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0,compresslevel=9) as z:z.write(data)


def worker(task):
    stage,idx,seq,t=task
    model=stage_model(seq,False) if stage=="stage1" else stage_model(seq,True) if stage=="stage2" else class_model(seq,t)
    cert,meta=find_farkas(model)
    if cert is None:return [idx,None,meta]
    z=[0]*len(model.standard_form_sparse()[0])
    for i,a in cert:z[i]=a
    ok,why=exact_check_z(model,z)
    if not ok:return [idx,None,{"status":"generator_postcheck_failed","why":why}]
    return [idx,cert,meta]


def run_stage(out:Path,stage:str,source:list,survivors:list,jobs:int,shard_size:int):
    survivor_set=set(survivors)
    tasks=[(stage,i,s,t) for i,(s,t) in enumerate(source) if (s,t) not in survivor_set]
    records=[];shards=[];modes=Counter();supports=[];failed=[];started=time.time()
    with ProcessPoolExecutor(max_workers=jobs) as ex:
        for done,(idx,cert,meta) in enumerate(ex.map(worker,tasks,chunksize=32 if stage=="stage1" else 8),1):
            if cert is None:failed.append([idx,meta])
            else:
                records.append([idx,cert]);modes[meta.get("mode","?")]+=1;supports.append(len(cert))
            if len(records)>=shard_size:
                name=f"{stage}_{len(shards):04d}.json.gz";write_gzip_json(out/name,{"format":"s20-standard-form-farkas-z-v1","stage":stage,"records":records});shards.append(name);records=[]
            if done%2000==0:print(stage,done,"/",len(tasks),flush=True)
    if records:
        name=f"{stage}_{len(shards):04d}.json.gz";write_gzip_json(out/name,{"format":"s20-standard-form-farkas-z-v1","stage":stage,"records":records});shards.append(name)
    if failed:
        (out/f"{stage}_failures.json").write_text(json.dumps(failed,indent=2)+"\n")
        raise RuntimeError(f"{stage}: {len(failed)} uncovered cases")
    summary={"stage":stage,"source_count":len(source),"survivor_count":len(survivors),"leaf_count":len(tasks),"shards":shards,"mode_counts":dict(modes),"support_min":min(supports),"support_max":max(supports),"support_sum":sum(supports),"elapsed_seconds":time.time()-started}
    (out/f"{stage}_summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
    return summary


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--output",type=Path,default=ROOT/"regenerated_certs")
    ap.add_argument("--jobs",type=int,default=max(1,min(4,os.cpu_count() or 1)))
    ap.add_argument("--force",action="store_true")
    args=ap.parse_args()
    out=args.output.resolve()
    if out== (ROOT/"certs").resolve():raise SystemExit("refusing to overwrite sealed certs/")
    if out.exists():
        if not args.force:raise SystemExit(f"output exists: {out}; use --force")
        shutil.rmtree(out)
    out.mkdir(parents=True)
    reps=read_pairs("complement_representatives.txt.gz")
    s1=read_pairs("stage1_survivors.txt.gz")
    s2=read_pairs("stage2_survivors.txt.gz")
    root_meta=json.loads((ROOT/"data/final_integer_roots.json").read_text())["roots"]
    roots=[(tuple(x["sequence"]),int(x["triangles"])) for x in root_meta]
    a=run_stage(out,"stage1",reps,s1,args.jobs,2000)
    b=run_stage(out,"stage2",s1,s2,args.jobs,1000)
    c=run_stage(out,"class",s2,roots,args.jobs,100)
    branch=[]
    for info,(seq,t) in zip(root_meta,roots):
        m=class_model(seq,t);j=int(info["branch_variable_index"]);floor=int(info["floor"])
        left=apply_upper_branch(m,j,floor,True);right=apply_upper_branch(m,j,floor,False)
        lc,lm=find_farkas(left);rc,rm=find_farkas(right)
        if lc is None or rc is None:raise RuntimeError({"branch":info,"left":lm,"right":rm})
        branch.append({"root_index":info["root_index"],"sequence":info["sequence"],"triangles":t,"variable_index":j,"variable_name":info["branch_variable_name"],"floor":floor,"left_cert":lc,"right_cert":rc})
    write_gzip_json(out/"branch_leaves.json.gz",{"format":"s20-branch-farkas-v1","roots":branch,"leaf_count":4})
    total=a["leaf_count"]+b["leaf_count"]+c["leaf_count"]+4
    master={"format":"s20-certificate-generation-summary-v1","stage1":a,"stage2":b,"class":c,"branch":{"roots":2,"leaves":4},"total_leaf_count":total}
    (out/"SUMMARY.json").write_text(json.dumps(master,indent=2,sort_keys=True)+"\n")
    if total!=80124:raise RuntimeError(f"wrong total {total}")
    print(json.dumps({"status":"GENERATION_COMPLETE","output":str(out),"total_leaf_count":total},sort_keys=True))
    return 0

if __name__=="__main__":raise SystemExit(main())
