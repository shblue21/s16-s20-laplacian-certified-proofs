#!/usr/bin/env python3
"""Independent n=20 degree-sequence coverage audit.

This implementation uses a position-by-position nondecreasing-sequence DP and
Havel--Hakimi.  It does not import the verifier's multiplicity recursion or its
Erdos--Gallai implementation.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import gzip
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

class AuditError(RuntimeError): pass

def require(c,m):
    if not c: raise AuditError(str(m))

@lru_cache(None)
def possible(r:int, lower:int, s:int, q:int)->bool:
    if r==0: return s==0 and q==0
    if lower>17: return False
    if s<r*lower or s>17*r or q<r*lower*lower or q>17*17*r: return False
    if q*r<s*s: return False
    return any(possible(r-1,x,s-x,q-x*x) for x in range(lower,18))

def enumerate_positionally():
    out=[]; a=[]
    def rec(r,lower,s,q):
        if r==0:
            if s==q==0: out.append(tuple(a))
            return
        for x in range(lower,18):
            if possible(r-1,x,s-x,q-x*x):
                a.append(x);rec(r-1,x,s-x,q-x*x);a.pop()
    rec(20,2,190,2280)
    return out

def havel_hakimi(seq):
    d=sorted(seq,reverse=True)
    while d:
        x=d.pop(0)
        if x>len(d): return False
        for i in range(x):
            d[i]-=1
            if d[i]<0:return False
        d.sort(reverse=True)
    return True

def lines(items,pair=False):
    if pair:return ''.join(' '.join(map(str,s))+'|'+str(t)+'\n' for s,t in items).encode('ascii')
    return ''.join(' '.join(map(str,s))+'\n' for s in items).encode('ascii')

def readgz(name):
    with gzip.open(DATA/name,'rb') as f:return f.read()

def main():
    st=time.time()
    moment=enumerate_positionally()
    require(len(moment)==209932,len(moment))
    require(lines(moment)==readgz('moment_sequences.txt.gz'),'moment list mismatch')
    graphical=[s for s in moment if havel_hakimi(s)]
    require(len(graphical)==200108,len(graphical))
    require(lines(graphical)==readgz('graphical_sequences.txt.gz'),'graphical list mismatch')
    base=[]
    for s in graphical:
        z=sum(x**3 for x in s)-29260
        if z%6==0 and 127<=z//6<=348:base.append((s,z//6))
    require(len(base)==160244,len(base))
    require(lines(base,True)==readgz('base_sequences.txt.gz'),'base list mismatch')
    bset=set(base);reps=[];seen=set();fixed=[]
    for item in base:
        if item in seen:continue
        s,t=item;mate=(tuple(sorted(19-x for x in s)),475-t)
        require(mate in bset,(item,mate))
        if mate==item:fixed.append(item)
        reps.append(min(item,mate));seen.add(item);seen.add(mate)
    reps.sort()
    require(not fixed,fixed[:3]);require(len(reps)==80122,len(reps))
    require(lines(reps,True)==readgz('complement_representatives.txt.gz'),'representative list mismatch')
    require(readgz('stage1_source.txt.gz')==readgz('complement_representatives.txt.gz'),'Stage 1 source alias mismatch')
    require(readgz('stage2_source.txt.gz')==readgz('stage1_survivors.txt.gz'),'Stage 2 source alias mismatch')
    require(readgz('class_source.txt.gz')==readgz('stage2_survivors.txt.gz'),'class source alias mismatch')
    require(readgz('class_survivors.txt.gz').count(b'\n')==2,'class survivor count')
    result={
        'status':'INDEPENDENT_ENUMERATION_PASS',
        'implementation':'position-DP plus Havel-Hakimi',
        'moment_sequences':len(moment),'graphical_sequences':len(graphical),
        'base_sequences':len(base),'complement_representatives':len(reps),
        'complement_fixed_points':len(fixed),
        'representative_sha256':hashlib.sha256(lines(reps,True)).hexdigest(),
        'dp_cache':{'hits':possible.cache_info().hits,'misses':possible.cache_info().misses},
        'elapsed_seconds':round(time.time()-st,6),
    }
    print(json.dumps(result,sort_keys=True));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        print(json.dumps({'status':'INDEPENDENT_ENUMERATION_FAILED','error':str(e)},sort_keys=True),file=sys.stderr);raise SystemExit(2)
