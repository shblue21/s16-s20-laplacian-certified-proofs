#!/usr/bin/env python3
"""Definition-level semantic audit of the n=20 graph identities used by the models."""
from __future__ import annotations
from itertools import combinations
from collections import Counter
from math import comb
from pathlib import Path
import json
import random
import sys
import time

class AuditError(RuntimeError): pass

def require(c,m):
    if not c: raise AuditError(str(m))

def graph_from_edges(edges):
    A=[[0]*20 for _ in range(20)]
    for i,j in edges:
        require(0<=i<j<20,(i,j));A[i][j]=A[j][i]=1
    return A

def complement(A):
    return [[0 if i==j else 1-A[i][j] for j in range(20)] for i in range(20)]

def mm(A,B):
    n=len(A);return [[sum(A[i][k]*B[k][j] for k in range(n)) for j in range(n)] for i in range(n)]

def audit(A):
    n=20
    require(all(len(r)==n for r in A),'shape')
    require(all(A[i][i]==0 for i in range(n)),'diagonal')
    require(all(A[i][j] in (0,1) and A[i][j]==A[j][i] for i in range(n) for j in range(n)),'simple symmetric')
    d=[sum(r) for r in A];m=sum(d)//2
    L=[[(-A[i][j] if i!=j else d[i]) for j in range(n)] for i in range(n)]
    L2=mm(L,L);L3=mm(L2,L);L4=mm(L2,L2)
    c=[[sum(A[i][k]*A[j][k] for k in range(n)) for j in range(n)] for i in range(n)]
    q=[];s=[]
    for v in range(n):
        qv=sum(A[v][i]*A[v][j]*A[i][j] for i in range(n) for j in range(i+1,n))
        q.append(qv);s.append(sum(A[v][w]*d[w] for w in range(n)))
        require(L2[v][v]==d[v]*d[v]+d[v],('L2diag',v))
        require(L3[v][v]==d[v]**3+2*d[v]**2+s[v]-2*q[v],('L3diag',v,L3[v][v],d[v]**3+2*d[v]**2+s[v]-2*q[v]))
    tr4=sum(L4[i][i] for i in range(n))
    rhs4=sum((d[i]*d[i]+d[i])**2 for i in range(n))
    rhs4+=2*sum((c[i][j]-A[i][j]*(d[i]+d[j]))**2 for i in range(n) for j in range(i+1,n))
    require(tr4==rhs4,('L4',tr4,rhs4))
    triangles=sum(q)//3
    require(sum(c[i][j] for i in range(n) for j in range(i+1,n))==sum(comb(x,2) for x in d),'all-pair common-neighbor sum')
    require(sum(c[i][j] for i in range(n) for j in range(i+1,n) if A[i][j])==3*triangles,'edge common-neighbor sum')
    B=complement(A);db=[19-x for x in d]
    cb=[[sum(B[i][k]*B[j][k] for k in range(n)) for j in range(n)] for i in range(n)]
    qb=[]
    for v in range(n):
        qbv=sum(B[v][i]*B[v][j]*B[i][j] for i in range(n) for j in range(i+1,n));qb.append(qbv)
        require(qbv==comb(19-d[v],2)-m+s[v]-q[v],('local complement triangle',v,qbv,comb(19-d[v],2)-m+s[v]-q[v]))
    for i in range(n):
        for j in range(i+1,n):
            require(cb[i][j]==18-d[i]-d[j]+2*A[i][j]+c[i][j],('complement common neighbors',i,j))
    require(triangles+sum(qb)//3==comb(20,3)-sum(d[i]*(19-d[i]) for i in range(n))//2,'Goodman identity')

    # Independently aggregate the degree-pair/degree-triple variables used by
    # the class relaxation and check every combinatorial row/bound.
    cnt=Counter(d);ds=sorted(cnt)
    pairs=[(a,b) for ii,a in enumerate(ds) for b in ds[ii:]]
    E=Counter()
    for i in range(n):
        for j in range(i+1,n):
            if A[i][j]:E[tuple(sorted((d[i],d[j])))] += 1
    TG=Counter();TC=Counter()
    for i,j,k in combinations(range(n),3):
        z=tuple(sorted((d[i],d[j],d[k])))
        if A[i][j] and A[i][k] and A[j][k]:TG[z]+=1
        if B[i][j] and B[i][k] and B[j][k]:TC[z]+=1
    require(sum(TG.values())==triangles,'class graph triangle total')
    require(sum(TC.values())==sum(qb)//3,'class complement triangle total')
    for dd in ds:
        stub=2*E[dd,dd]+sum(E[tuple(sorted((dd,b)))] for b in ds if b!=dd)
        require(stub==cnt[dd]*dd,('class stubs',dd,stub,cnt[dd]*dd))
        sg=sum(s[v] for v in range(n) if d[v]==dd)
        sg2=2*dd*E[dd,dd]+sum(b*E[tuple(sorted((dd,b)))] for b in ds if b!=dd)
        require(sg==sg2,('class neighbor-degree sum',dd,sg,sg2))
        rg=sum(q[v] for v in range(n) if d[v]==dd)
        rg2=sum(z.count(dd)*num for z,num in TG.items())
        require(rg==rg2,('class graph triangle incidences',dd,rg,rg2))
        sc=sum(sum(B[v][w]*db[w] for w in range(n)) for v in range(n) if d[v]==dd)
        sc2=2*(19-dd)*(comb(cnt[dd],2)-E[dd,dd])
        sc2+=sum((19-b)*(cnt[dd]*cnt[b]-E[tuple(sorted((dd,b)))]) for b in ds if b!=dd)
        require(sc==sc2,('class complement neighbor-degree sum',dd,sc,sc2))
        rc=sum(qb[v] for v in range(n) if d[v]==dd)
        rc2=sum(z.count(dd)*num for z,num in TC.items())
        require(rc==rc2,('class complement triangle incidences',dd,rc,rc2))
        require(rg<=cnt[dd]*comb(dd,2),('graph wedge bound',dd))
        require(rc<=cnt[dd]*comb(19-dd,2),('complement wedge bound',dd))
    for a,b in pairs:
        cap=comb(cnt[a],2) if a==b else cnt[a]*cnt[b]
        pairG=0;pairC=0
        for z,num in TG.items():
            cc=Counter(z);pairG+=(comb(cc[a],2) if a==b else cc[a]*cc[b])*num
        for z,num in TC.items():
            cc=Counter(z);pairC+=(comb(cc[a],2) if a==b else cc[a]*cc[b])*num
        require(pairG<=(min(a,b)-1)*E[a,b],('edge-triangle bound',a,b))
        require(pairC<=(18-max(a,b))*(cap-E[a,b]),('complement edge-triangle bound',a,b))
    return {'edges':m,'triangles':triangles,'trace_L4':tr4,'degree_classes':len(ds)}

def main():
    st=time.time();reports=[]
    structured=[]
    structured.append([])
    structured.append(list(combinations(range(20),2)))
    structured.append([(i,i+1) for i in range(19)])
    structured.append([(i,(i+1)%20) if i<19 else (0,19) for i in range(19)])
    structured.append([(0,i) for i in range(1,20)])
    structured.append([(i,j) for i in range(10) for j in range(10,20)])
    for e in structured:reports.append(audit(graph_from_edges(e)))
    rng=random.Random(0x52020260821)
    all_edges=list(combinations(range(20),2))
    exact95=0
    for _ in range(120):
        edges=rng.sample(all_edges,95);r=audit(graph_from_edges(edges));require(r['edges']==95,'95-edge generation');exact95+=1
    for _ in range(80):
        k=rng.randrange(0,191);reports.append(audit(graph_from_edges(rng.sample(all_edges,k))))
    # Independently evaluate the target constants, including the specialized common-neighbor total.
    require(sum(comb(x,2) for x in [0])==0,'comb sanity')
    require(sum(k**4 for k in range(20))==562666,'target trace L4')
    require((2280-190)//2==1045,'target all-pair common-neighbor total')
    result={'status':'GRAPH_IDENTITY_AUDIT_PASS','structured_graphs':len(structured),'random_95_edge_graphs':exact95,'other_random_graphs':80,'elapsed_seconds':round(time.time()-st,6)}
    print(json.dumps(result,sort_keys=True));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        print(json.dumps({'status':'GRAPH_IDENTITY_AUDIT_FAILED','error':str(e)},sort_keys=True),file=sys.stderr);raise SystemExit(2)
