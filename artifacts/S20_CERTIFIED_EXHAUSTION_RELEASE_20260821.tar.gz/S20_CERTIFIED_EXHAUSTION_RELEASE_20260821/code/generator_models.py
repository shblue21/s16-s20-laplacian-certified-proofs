#!/usr/bin/env python3
"""Untrusted SciPy/SymPy certificate-generation models for the n=20 release.

The trusted verifier is code/verify_certificates.py and does not import this file.
"""
from __future__ import annotations
import math
from collections import Counter
from dataclasses import dataclass
from itertools import combinations_with_replacement
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog

N=20
K=range(1,20)

@dataclass
class Model:
    names:list
    eq:list      # list[(dict[int,int], int)]
    ub:list      # list[(dict[int,int], int)]
    lo:list      # finite int lower bounds
    hi:list      # int|None upper bounds
    integer:set

    def standard_form_dense(self):
        """Return B,h for B w=h,w>=0 after shifting finite lower bounds and adding slacks."""
        nv=len(self.names)
        if len(self.lo)!=nv or len(self.hi)!=nv or any(x is None for x in self.lo):
            raise ValueError('all lower bounds must be finite')
        upper=[j for j,u in enumerate(self.hi) if u is not None]
        nr=len(self.eq)+len(self.ub)+len(upper)
        nc=nv+len(self.ub)+len(upper)
        B=np.zeros((nr,nc),dtype=float)
        h=np.zeros(nr,dtype=float)
        r=0
        for row,b in self.eq:
            for j,a in row.items():B[r,j]=a
            h[r]=b-sum(row.get(j,0)*self.lo[j] for j in row)
            r+=1
        for ui,(row,b) in enumerate(self.ub):
            for j,a in row.items():B[r,j]=a
            B[r,nv+ui]=1
            h[r]=b-sum(row.get(j,0)*self.lo[j] for j in row)
            r+=1
        for qi,j in enumerate(upper):
            B[r,j]=1
            B[r,nv+len(self.ub)+qi]=1
            h[r]=self.hi[j]-self.lo[j]
            r+=1
        assert r==nr
        return B,h

    def standard_form_sparse(self):
        """Pure-integer rows/columns representation for exact checking.
        Returns rows h and original-variable column contributions plus implicit slack sign rows.
        We check z by accumulating B^T z without materializing slacks.
        """
        upper=[j for j,u in enumerate(self.hi) if u is not None]
        rows=[]; h=[]; kinds=[]
        for row,b in self.eq:
            rows.append(row);h.append(b-sum(a*self.lo[j] for j,a in row.items()));kinds.append(('eq',None))
        for i,(row,b) in enumerate(self.ub):
            rows.append(row);h.append(b-sum(a*self.lo[j] for j,a in row.items()));kinds.append(('ub',i))
        for j in upper:
            rows.append({j:1});h.append(self.hi[j]-self.lo[j]);kinds.append(('upper',j))
        return rows,h,kinds


def addrow(target:dict,j:int,a:int):
    if a:
        target[j]=target.get(j,0)+a
        if target[j]==0:del target[j]


def stage_model(seq,third=False):
    cnt=Counter(seq); ds=sorted(cnt); names=[];Y={}
    for d in ds:
        for k in K:Y[d,k]=len(names);names.append(('Y',d,k))
    S={}
    if third:
        for d in ds:S[d]=len(names);names.append(('S',d))
    eq=[];ub=[]
    for d in ds:
        m=cnt[d]
        eq.append(({Y[d,k]:1 for k in K},19*m))
        eq.append(({Y[d,k]:k for k in K},20*m*d))
        eq.append(({Y[d,k]:k*k for k in K},20*m*(d*d+d)))
    for k in K:eq.append(({Y[d,k]:1 for d in ds},20))
    lo=[0]*len(names);hi=[None]*len(names)
    if third:
        for d in ds:
            m=cnt[d];b0=d**3+2*d*d;y3={Y[d,k]:k**3 for k in K};j=S[d]
            z=list(seq);z.remove(d);z.sort();lo[j]=m*sum(z[:d]);hi[j]=m*sum(z[-d:])
            ub.append(({q:-a for q,a in y3.items()},-20*m*(b0+d)))
            ub.append((dict(y3),20*m*(b0+d*(20-d))))
            r=dict(y3);r[j]=-20;ub.append((r,20*m*b0))
            r={q:-a for q,a in y3.items()};r[j]=20;ub.append((r,40*m*math.comb(d,2)-20*m*b0))
            R=190-2*math.comb(19-d,2)
            r={q:-a for q,a in y3.items()};r[j]=-20;ub.append((r,-20*m*(R+b0)))
            r=dict(y3);r[j]=20;ub.append((r,20*m*(190+b0)))
        eq.append(({S[d]:1 for d in ds},2280))
    return Model(names,eq,ub,lo,hi,set())


def triple_capacity(z,cnt):
    cc=Counter(z);p=1
    for d,r in cc.items():
        if r>cnt[d]:return 0
        p*=math.comb(cnt[d],r)
    return p


def class_model(seq,t):
    cnt=Counter(seq);ds=sorted(cnt);names=[];Y={}
    for d in ds:
        for k in K:Y[d,k]=len(names);names.append(('Y',d,k))
    pairs=[(a,b) for i,a in enumerate(ds) for b in ds[i:]]
    E={}
    for p in pairs:E[p]=len(names);names.append(('E',)+p)
    triples=[z for z in combinations_with_replacement(ds,3) if triple_capacity(z,cnt)>0]
    T={}
    for z in triples:T[z]=len(names);names.append(('T',)+z)
    C={}
    for z in triples:C[z]=len(names);names.append(('C',)+z)
    eq=[];ub=[]
    # spectral
    for d in ds:
        m=cnt[d]
        eq.append(({Y[d,k]:1 for k in K},19*m))
        eq.append(({Y[d,k]:k for k in K},20*m*d))
        eq.append(({Y[d,k]:k*k for k in K},20*m*(d*d+d)))
    for k in K:eq.append(({Y[d,k]:1 for d in ds},20))
    # stubs
    for d in ds:
        r={}
        for a,b in pairs:
            if a==b==d:addrow(r,E[a,b],2)
            elif a==d or b==d:addrow(r,E[a,b],1)
        eq.append((r,cnt[d]*d))
    eq.append(({T[z]:1 for z in triples},t))
    eq.append(({C[z]:1 for z in triples},475-t))
    # G L3
    for d in ds:
        m=cnt[d];b0=d**3+2*d*d;r={Y[d,k]:k**3 for k in K}
        for a,b in pairs:
            q=2*d if a==b==d else (b if a==d else (a if b==d else 0))
            if q:addrow(r,E[a,b],-20*q)
        for z in triples:
            q=z.count(d)
            if q:addrow(r,T[z],40*q)
        eq.append((r,20*m*b0))
    # complement L3
    for d in ds:
        m=cnt[d];db=19-d;b0=db**3+2*db*db;r={Y[d,20-k]:k**3 for k in K};const=0
        for a,b in pairs:
            cap=math.comb(cnt[a],2) if a==b else cnt[a]*cnt[b]
            q=2*(19-d) if a==b==d else ((19-b) if a==d else ((19-a) if b==d else 0))
            if q:
                const+=q*cap;addrow(r,E[a,b],20*q)
        for z in triples:
            q=z.count(d)
            if q:addrow(r,C[z],40*q)
        eq.append((r,20*m*b0+20*const))
    # incidences
    for a,b in pairs:
        cap=math.comb(cnt[a],2) if a==b else cnt[a]*cnt[b];rg={};rc={}
        for z in triples:
            cc=Counter(z);q=math.comb(cc[a],2) if a==b else cc[a]*cc[b]
            if q:addrow(rg,T[z],q);addrow(rc,C[z],q)
        addrow(rg,E[a,b],-(min(a,b)-1));ub.append((rg,0))
        q=18-max(a,b);addrow(rc,E[a,b],q);ub.append((rc,q*cap))
    for d in ds:
        rg={};rc={}
        for z in triples:
            q=z.count(d)
            if q:addrow(rg,T[z],q);addrow(rc,C[z],q)
        ub.append((rg,cnt[d]*math.comb(d,2)))
        ub.append((rc,cnt[d]*math.comb(19-d,2)))
    lo=[0]*len(names);hi=[None]*len(names);integer=set()
    for a,b in pairs:
        j=E[a,b];hi[j]=math.comb(cnt[a],2) if a==b else cnt[a]*cnt[b];integer.add(j)
    for z in triples:
        cap=triple_capacity(z,cnt)
        for D in (T,C):j=D[z];hi[j]=cap;integer.add(j)
    return Model(names,eq,ub,lo,hi,integer)


def exact_check_z(model:Model,zints:list[int]):
    rows,h,kinds=model.standard_form_sparse()
    if len(zints)!=len(rows):return False,'length'
    lhs=[0]*len(model.names)
    rhs=0
    for i,(zi,row,bi) in enumerate(zip(zints,rows,h)):
        if zi:
            rhs += zi*bi
            for j,a in row.items():lhs[j]+=zi*a
    # standard-form original-variable columns
    bad=next(((j,v) for j,v in enumerate(lhs) if v<0),None)
    if bad is not None:return False,('negative_original_column',bad)
    # each inequality/upper-bound row has a dedicated +1 slack column
    for i,(kind,_) in enumerate(kinds):
        if kind!='eq' and zints[i]<0:return False,('negative_slack_column',i,zints[i],kind)
    if rhs>=0:return False,('rhs_nonnegative',rhs)
    return True,rhs


def integerize_solution(model,z,tolerances=(10,100,1000,10000,100000,1000000,10000000,100000000,1000000000,10000000000,1000000000000)):
    z=np.asarray(z,dtype=float)
    # common-denominator rounding first
    for q in tolerances:
        zi=[int(round(x*q)) for x in z]
        g=0
        for x in zi:g=math.gcd(g,abs(x))
        if g>1:zi=[x//g for x in zi]
        ok,why=exact_check_z(model,zi)
        if ok:return zi,('common',q,why)
    # individual rational reconstruction
    for D in (100,1000,10000,100000,1000000,10000000,100000000):
        fs=[Fraction(float(x)).limit_denominator(D) for x in z]
        l=1
        for f in fs:
            l=math.lcm(l,f.denominator)
            if l.bit_length()>4096:break
        else:
            zi=[f.numerator*(l//f.denominator) for f in fs]
            g=0
            for x in zi:g=math.gcd(g,abs(x))
            if g>1:zi=[x//g for x in zi]
            ok,why=exact_check_z(model,zi)
            if ok:return zi,('fraction',D,why)
    return None,why



def recover_l1_exact(model:Model, qfloat, zero_tol=1e-8, active_tol=1e-7):
    """Recover an exact integer z from a minimum-L1 split solution q=(p,n).

    On the positive support of a basic LP solution, the normalization row and
    active dual inequalities determine the support values.  We select a
    numerically independent square subsystem, solve that integer system exactly
    with SymPy, then audit all standard-form columns using Python integers.
    """
    import sympy as sp
    B,h=model.standard_form_dense(); C=B.T; r=len(h)
    qv=np.asarray(qfloat,dtype=float)
    support=[j for j,x in enumerate(qv) if x>zero_tol]
    if not support:
        return None,{'status':'empty_l1_support'}
    z=qv[:r]-qv[r:]
    vals=C@z
    active=[i for i,x in enumerate(vals) if abs(x)<=active_tol]
    def restrict(base):
        return [int(base[j]) if j<r else -int(base[j-r]) for j in support]
    norm=restrict(h)
    rows={i:restrict(C[i]) for i in active}
    # Sparse-first modified Gram-Schmidt, forcing the normalization row first.
    # Choosing low-support active rows dramatically reduces exact elimination fill.
    qbasis=[]; ids=[-1]
    v=np.asarray(norm,dtype=float); nv=float(np.linalg.norm(v))
    if nv==0:return None,{'status':'zero_normalization_row'}
    qbasis.append(v/nv)
    ordered=sorted(
        ((i,np.asarray(row,dtype=float)) for i,row in rows.items()),
        key=lambda item:(int(np.count_nonzero(item[1])),float(np.max(np.abs(item[1]))) if np.any(item[1]) else 0.0,float(np.linalg.norm(item[1])))
    )
    for i,v0 in ordered:
        w=v0.copy()
        for _ in range(2):
            for u in qbasis:w-=float(np.dot(u,w))*u
        wn=float(np.linalg.norm(w))
        if wn>1e-8:
            ids.append(i);qbasis.append(w/wn)
            if len(qbasis)==len(support):break
    if len(qbasis)<len(support):
        return None,{'status':'active_rank_failure','rank':len(qbasis),'support':len(support),'active':len(active)}
    square=[norm]+[rows[i] for i in ids[1:]]
    ss=len(support)
    M=sp.polys.matrices.DomainMatrix.from_list_sympy(ss,ss,square)
    bb=sp.polys.matrices.DomainMatrix.from_list_sympy(ss,1,[[-1]]+[[0]]*(ss-1))
    try:
        num,den=M.solve_den(bb,method='rref')
    except Exception as exc:
        return None,{'status':'exact_solve_failed','error':repr(exc),'support':ss}
    mat=num.to_Matrix(); deni=int(den.element) if hasattr(den,'element') else int(den)
    qi=[int(mat[i,0]) for i in range(ss)]
    if deni<0:deni=-deni;qi=[-x for x in qi]
    if any(x<0 for x in qi):
        return None,{'status':'negative_exact_l1_component','minimum':min(qi),'support':ss}
    zi=[0]*r
    for j,x in zip(support,qi):
        if j<r:zi[j]+=x
        else:zi[j-r]-=x
    g=0
    for x in zi:g=math.gcd(g,abs(x))
    if g>1:zi=[x//g for x in zi]
    ok,why=exact_check_z(model,zi)
    if not ok:return None,{'status':'exact_recovery_audit_failed','why':why,'support':ss}
    return zi,{'status':0,'method':'l1_exact_basis','rhs':why,'support':sum(x!=0 for x in zi),'basis_support':ss,'active':len(active)}

def find_farkas(model:Model,presolve=True):
    B,h=model.standard_form_dense();nr=B.shape[0]; C=B.T
    # First solve directly in free z variables.
    res=linprog(np.zeros(nr),A_ub=-C,b_ub=np.zeros(B.shape[1]),A_eq=h.reshape(1,-1),b_eq=np.array([-1.0]),bounds=[(None,None)]*nr,method='highs-ds',options={'presolve':presolve})
    if res.status!=0:return None,{'status':res.status,'message':res.message}
    zi,meta=integerize_solution(model,res.x)
    mode='direct'
    if zi is None:
        # A minimum-L1 dual point is usually a much sparser basic rational point,
        # and is substantially easier to reconstruct exactly.
        Aub=np.hstack([-C,C]); Aeq=np.hstack([h.reshape(1,-1),-h.reshape(1,-1)])
        rr=linprog(np.ones(2*nr),A_ub=Aub,b_ub=np.zeros(C.shape[0]),A_eq=Aeq,b_eq=np.array([-1.0]),bounds=(0,None),method='highs-ds',options={'presolve':presolve})
        if rr.status!=0:return None,{'status':'l1_failed','message':rr.message,'direct_message':str(meta)}
        z=rr.x[:nr]-rr.x[nr:]
        zi,meta=integerize_solution(model,z)
        mode='l1'
        if zi is None:
            zi,meta=recover_l1_exact(model,rr.x)
            mode='l1_exact_basis'
            if zi is None:
                return None,{'status':'rationalization_failed','message':str(meta),'mincol':float(np.min(C@z)),'rhs':float(h@z)}
    if isinstance(meta,dict):
        out=dict(meta);out.update({'status':0,'mode':mode,'rows':nr,'cols':B.shape[1],'support':sum(x!=0 for x in zi)})
    else:
        out={'status':0,'mode':mode,'method':meta[0],'scale':meta[1],'rhs':meta[2],'support':sum(x!=0 for x in zi),'rows':nr,'cols':B.shape[1]}
    return [[i,x] for i,x in enumerate(zi) if x],out


def apply_upper_branch(model:Model,j:int,bound:int,left:bool):
    # clone shallow immutable rows; bounds copied
    lo=list(model.lo);hi=list(model.hi)
    if left:
        hi[j]=bound if hi[j] is None else min(hi[j],bound)
    else:
        lo[j]=max(lo[j],bound+1)
    return Model(model.names,model.eq,model.ub,lo,hi,model.integer)
