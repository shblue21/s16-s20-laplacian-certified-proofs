#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 code/generate_certificates.py --output regenerated_certs --force "$@"
echo 'Generation completed. Compare regenerated coverage and run the trusted verifier after replacing certs in a separate copy.'
