#!/usr/bin/env bash
set -u -o pipefail
export PYTHONDONTWRITEBYTECODE=1
status=0
run_cmd() {
  printf '\n===== COMMAND:'
  printf ' %q' "$@"
  printf ' =====\n'
  "$@"
  rc=$?
  printf '===== EXIT CODE: %d =====\n' "$rc"
  if [ "$rc" -ne 0 ]; then status="$rc"; fi
}
run_cmd python3 code/verify_certificates.py
run_cmd python3 -O code/verify_certificates.py
run_cmd python3 code/independent_enumeration_audit.py
run_cmd python3 code/audit_graph_identities.py
run_cmd python3 code/mutation_audit_final.py
if [ "$status" -eq 0 ]; then
  echo '===== REPRODUCE.sh RESULT: PASS ====='
else
  echo "===== REPRODUCE.sh RESULT: FAIL ($status) =====" >&2
fi
exit "$status"
