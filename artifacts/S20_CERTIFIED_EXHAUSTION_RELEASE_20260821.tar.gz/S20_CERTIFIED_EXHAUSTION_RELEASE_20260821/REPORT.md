# S20 consecutive Laplacian spectrum: certified exhaustion release

## 1. Decision

There is no simple undirected graph on 20 vertices whose Laplacian spectrum is exactly

\[
\{0,1,2,\ldots,19\}.
\]

**Result grade: SOLVED—CERTIFIED EXHAUSTION.** This grade applies to this sealed release only after the recorded clean replay succeeds with exit code 0.

## 2. Certificate statement

For every candidate degree sequence, the verifier reconstructs a necessary linear relaxation from the sequence and the n=20 formulas. It converts that relaxation to

\[
B w=h,\qquad w\ge 0.
\]

Each leaf stores a sparse integer vector \(z\) satisfying

\[
B^{\mathsf T}z\ge0,\qquad h^{\mathsf T}z<0.
\]

These two integer identities contradict feasibility. Serialized constraint matrices are not trusted; `code/verify_certificates.py` rebuilds every model.

## 3. Exhaustive counts

| Stage | Source | Eliminated by exact leaf | Survivor |
|---|---:|---:|---:|
| first two degree moments | 209,932 | — | 209,932 |
| graphicality | 209,932 | 9,824 | 200,108 |
| triangle integrality and bounds | 200,108 | 39,864 | 160,244 |
| complement representatives | 160,244 | symmetry pairing | 80,122 |
| spectral-weight model | 80,122 | 63,235 | 16,887 |
| local third-moment/complement model | 16,887 | 16,542 | 345 |
| degree-pair/triple class model | 345 | 343 | 2 integer roots |
| exhaustive integer split | 2 roots | 4 leaves | 0 |

The total exact leaf count is

\[
63{,}235+16{,}542+343+4=80{,}124.
\]

There are zero missing shards, uncovered cases, timeouts, UNKNOWN results, or crashes in the sealed coverage ledger.

## 4. Final two integer roots

The exact sequences, triangle counts, branch variable, floor, and the four child leaves are in `data/final_integer_roots.json` and `certs/branch_leaves.json.gz`.

Both roots branch on the integer variable \(E_{2,2}\), stored at model variable index 209, using the exhaustive split

\[
E_{2,2}\le0\quad\text{or}\quad E_{2,2}\ge1.
\]

All four children have exact integer Farkas certificates.

## 5. Independent coverage

The trusted verifier enumerates degree multiplicities and tests Erdős–Gallai inequalities. A separate script, `code/independent_enumeration_audit.py`, instead generates nondecreasing sequences position by position and tests Havel–Hakimi. Both reproduce

\[
209{,}932\to200{,}108\to160{,}244\to80{,}122.
\]

`data/complement_pairs.txt.gz` explicitly records every complement orbit and its unique representative. There are no fixed points.

## 6. n=20 parameter checks

The verifier explicitly requires:

- 20 vertices and spectrum 0 through 19;
- degree sum 190 and 95 edges;
- degree-square sum 2280;
- triangle offset 29260;
- degree range 2 through 17;
- triangle range 127 through 348 and complement total 475;
- fourth Laplacian trace 562666;
- spanning-tree count 6,082,255,020,441,600.

It rejects characteristic n=16 verifier residue.

## 7. Trusted computing base

The trusted checker uses the Python standard library only. NumPy, SciPy/HiGHS, SymPy, LP statuses, and floating-point dual vectors are generation aids and are not trusted.

The exact checker:

1. rebuilds constraints from the degree sequence;
2. shifts finite lower bounds and introduces standard-form slacks;
3. checks sparse multiplier indices and integer coefficients;
4. checks every slack multiplier sign;
5. checks every component of \(B^{\mathsf T}z\) is nonnegative;
6. checks \(h^{\mathsf T}z<0\);
7. checks complete source/survivor/leaf coverage;
8. checks both children of every integer branch;
9. runs unchanged under normal Python and `python -O`;
10. rejects unexpected Python files and manifest deviations.

## 8. Semantic and mutation audits

`code/audit_graph_identities.py` checks the local \(L^3\), complement-triangle, common-neighbor, and \(L^4\) identities directly on structured graphs and deterministic random graphs, including 120 graphs with exactly 95 edges.

`code/mutation_audit_final.py` confirms rejection of a sign-reversed certificate, an empty certificate, a missing leaf, a branch on a noninteger variable, and an unexpected Python file.

## 9. Reproduction

From the extracted release root:

```bash
sha256sum -c MANIFEST.sha256
bash REPRODUCE_FINAL.sh
```

Generation is separate and untrusted:

```bash
bash REGENERATE.sh
```

The final archive digest, complete tar listing, and fresh-directory replay transcript are distributed beside the archive and copied into `logs/` where possible without creating a self-referential archive hash.

## 10. Scope

This release establishes only the n=20 nonexistence result. It does not by itself prove the general conjecture for every order. The previously broken archive is not a premise of this proof.
