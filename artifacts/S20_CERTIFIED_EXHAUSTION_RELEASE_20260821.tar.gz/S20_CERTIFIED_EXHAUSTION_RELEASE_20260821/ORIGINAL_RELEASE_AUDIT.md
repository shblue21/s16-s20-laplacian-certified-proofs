# Original broken release: trust-boundary note

The previously linked S20 archive was not present in the active runtime when this replacement was built, so its exact bytes and the reported archive digest could not be rerun here. It is therefore not treated as evidence and is not incorporated into this release.

The separately attached `verify_certificates.py` was inspected and was an n=16 verifier: its model used 16 vertices, eigenvalues 0 through 15, degree sum 120, degree-square sum 1120, and triangle offset 11040. No code or certificate from that verifier is used by the trusted n=20 checker in this release.

This replacement was generated from a new n=20 enumeration and n=20 models. The release is accepted only if its own manifest, normal verifier, optimized verifier, independent enumeration, semantic audit, mutation audit, and fresh-directory replay all return exit code 0.
