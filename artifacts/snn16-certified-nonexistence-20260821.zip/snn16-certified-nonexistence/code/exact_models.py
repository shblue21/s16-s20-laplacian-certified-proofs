#!/usr/bin/env python3
"""Exact integer models used by the S_{16,16} certificate generator.
No floating-point arithmetic is used to construct the models.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations_with_replacement
from collections import Counter
from math import comb
from typing import Optional

Row = tuple[dict[int,int], int]

@dataclass
class Model:
    names: list[str]
    eq: list[Row]
    ub: list[Row]
    lo: list[int]
    hi: list[Optional[int]]
    integer: list[int]

    @property
    def nvar(self): return len(self.names)

    def all_ub(self, lo_override=None, hi_override=None):
        lo=self.lo if lo_override is None else lo_override
        hi=self.hi if hi_override is None else hi_override
        rows=list(self.ub)
        # deterministic order: lower bounds then upper bounds
        for j,a in enumerate(lo):
            if a is not None:
                rows.append(({j:-1},-int(a)))
        for j,b in enumerate(hi):
            if b is not None:
                rows.append(({j:1},int(b)))
        return rows

def is_graphical_eg(seq: tuple[int,...]) -> bool:
    d=sorted(seq,reverse=True); n=len(d)
    if sum(d)%2:return False
    pref=[0]
    for x in d:pref.append(pref[-1]+x)
    for k in range(1,n+1):
        if pref[k] > k*(k-1)+sum(min(x,k) for x in d[k:]):return False
    return True

def enumerate_base_sequences():
    out=[]
    for seq in combinations_with_replacement(range(2,14),16):
        if sum(seq)!=120 or sum(x*x for x in seq)!=1120:continue
        if not is_graphical_eg(seq):continue
        num=sum(x**3 for x in seq)-11040
        if num%6:continue
        t=num//6
        if 54<=t<=166:out.append((seq,t))
    return out

def neighbor_sum_bounds(seq:tuple[int,...],d:int):
    a=list(seq);a.remove(d);a.sort()
    return sum(a[:d]),sum(a[-d:])

def stage_model(seq:tuple[int,...], third:bool) -> Model:
    counts=Counter(seq); ds=sorted(counts)
    names=[]; y={}
    for d in ds:
        for k in range(1,16):
            y[d,k]=len(names);names.append(f"Y[{d},{k}]")
    S={}
    if third:
        for d in ds:S[d]=len(names);names.append(f"S[{d}]")
    eq=[];ub=[]
    def AE(row,rhs):eq.append((row,rhs))
    def AU(row,rhs):ub.append((row,rhs))
    for d in ds:
        m=counts[d]
        AE({y[d,k]:1 for k in range(1,16)},15*m)
        AE({y[d,k]:k for k in range(1,16)},16*m*d)
        AE({y[d,k]:k*k for k in range(1,16)},16*m*(d*d+d))
    for k in range(1,16):AE({y[d,k]:1 for d in ds},16)
    lo=[0]*len(names);hi=[None]*len(names)
    if third:
        for d in ds:
            m=counts[d];base=d**3+2*d**2;Y3={y[d,k]:k**3 for k in range(1,16)};si=S[d]
            nlo,nhi=neighbor_sum_bounds(seq,d);lo[si]=m*nlo;hi[si]=m*nhi
            # H >= md
            AU({j:-v for j,v in Y3.items()},-16*m*(base+d))
            # H <= m d(16-d)
            AU(dict(Y3),16*m*(base+d*(16-d)))
            # S >= H
            row=dict(Y3);row[si]=-16;AU(row,16*m*base)
            # S <= H+2m C(d,2)
            row={j:-v for j,v in Y3.items()};row[si]=16;AU(row,32*m*comb(d,2)-16*m*base)
            # S+H >= m(120-2C(15-d,2))
            R=120-2*comb(15-d,2)
            row={j:-v for j,v in Y3.items()};row[si]=-16;AU(row,-16*m*(R+base))
            # S+H <= 120m
            row=dict(Y3);row[si]=16;AU(row,16*m*(120+base))
        AE({S[d]:1 for d in ds},1120)
    return Model(names,eq,ub,lo,hi,[])

def tuple_capacity(t:tuple[int,int,int], counts:Counter):
    cc=Counter(t);p=1
    for d,r in cc.items():
        if r>counts[d]:return 0
        p*=comb(counts[d],r)
    return p

def class_model(seq:tuple[int,...], ttarget:int) -> Model:
    counts=Counter(seq);ds=sorted(counts)
    names=[];Y={}
    for d in ds:
        for k in range(1,16):Y[d,k]=len(names);names.append(f"Y[{d},{k}]")
    pairs=[(a,b) for i,a in enumerate(ds) for b in ds[i:]]
    E={}
    for p in pairs:E[p]=len(names);names.append(f"E[{p[0]},{p[1]}]")
    triples=[t for t in combinations_with_replacement(ds,3) if tuple_capacity(t,counts)>0]
    TG={}
    for q in triples:TG[q]=len(names);names.append(f"TG[{q[0]},{q[1]},{q[2]}]")
    TC={}
    for q in triples:TC[q]=len(names);names.append(f"TC[{q[0]},{q[1]},{q[2]}]")
    eq=[];ub=[]
    def AE(row,rhs):eq.append((row,rhs))
    def AU(row,rhs):ub.append((row,rhs))
    # spectral moments for G, aggregated by G-degree class
    for d in ds:
        m=counts[d]
        AE({Y[d,k]:1 for k in range(1,16)},15*m)
        AE({Y[d,k]:k for k in range(1,16)},16*m*d)
        AE({Y[d,k]:k*k for k in range(1,16)},16*m*(d*d+d))
    for k in range(1,16):AE({Y[d,k]:1 for d in ds},16)
    # class stub equations
    for d in ds:
        row={}
        for a,b in pairs:
            if a==b==d:row[E[a,b]]=2
            elif a==d or b==d:row[E[a,b]]=1
        AE(row,counts[d]*d)
    AE({TG[q]:1 for q in triples},ttarget)
    AE({TC[q]:1 for q in triples},220-ttarget)
    # G local third moments by class
    for d in ds:
        m=counts[d];base=d**3+2*d**2
        row={Y[d,k]:k**3 for k in range(1,16)}
        for a,b in pairs:
            coeff=2*d if a==b==d else (b if a==d else (a if b==d else 0))
            if coeff:row[E[a,b]]=row.get(E[a,b],0)-16*coeff
        for q in triples:
            mult=q.count(d)
            if mult:row[TG[q]]=row.get(TG[q],0)+32*mult
        AE(row,16*m*base)
    # complement local third moments; complement weights are Y[d,16-k]
    for d in ds:
        m=counts[d];db=15-d;base=db**3+2*db**2
        row={Y[d,16-k]:k**3 for k in range(1,16)}
        constS=0
        for a,b in pairs:
            cap=comb(counts[a],2) if a==b else counts[a]*counts[b]
            coeff=2*(15-d) if a==b==d else ((15-b) if a==d else ((15-a) if b==d else 0))
            if coeff:
                constS+=coeff*cap
                row[E[a,b]]=row.get(E[a,b],0)+16*coeff
        for q in triples:
            mult=q.count(d)
            if mult:row[TC[q]]=row.get(TC[q],0)+32*mult
        AE(row,16*m*base+16*constS)
    # pair/triangle incidence upper bounds, G and complement
    for a,b in pairs:
        cap=comb(counts[a],2) if a==b else counts[a]*counts[b]
        rg={};rc={}
        for q in triples:
            cc=Counter(q)
            mult=comb(cc[a],2) if a==b else cc[a]*cc[b]
            if mult:rg[TG[q]]=mult;rc[TC[q]]=mult
        rg[E[a,b]]=rg.get(E[a,b],0)-(min(a,b)-1)
        AU(rg,0)
        qmax=14-max(a,b)
        rc[E[a,b]]=rc.get(E[a,b],0)+qmax
        AU(rc,qmax*cap)
    # local wedge capacities, aggregated by degree class
    for d in ds:
        rg={};rc={}
        for q in triples:
            mult=q.count(d)
            if mult:rg[TG[q]]=mult;rc[TC[q]]=mult
        AU(rg,counts[d]*comb(d,2))
        AU(rc,counts[d]*comb(15-d,2))
    lo=[0]*len(names);hi=[None]*len(names);integer=[]
    for a,b in pairs:
        j=E[a,b];integer.append(j);hi[j]=comb(counts[a],2) if a==b else counts[a]*counts[b]
    for q in triples:
        cap=tuple_capacity(q,counts)
        for M in (TG,TC):
            j=M[q];integer.append(j);hi[j]=cap
    return Model(names,eq,ub,lo,hi,integer)
