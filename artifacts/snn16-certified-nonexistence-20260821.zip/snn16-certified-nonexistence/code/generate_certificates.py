#!/usr/bin/env python3
"""Regenerate the S_{16,16} exact certificate package.

Generation uses floating-point HiGHS only to discover candidate Farkas supports;
every emitted certificate is exactified and checked over Q before being written.
The final trusted check is code/verify_certificates.py, which needs only stdlib.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import gzip
import hashlib
import json
import math
import time

from exact_models import enumerate_base_sequences, stage_model, class_model
from farkas_tools import primal_solve, find_farkas, verify_farkas

ROOT = Path(__file__).resolve().parents[1]
CERTS = ROOT / "certs"
DATA = ROOT / "data"
CERTS.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)


def write_gzip_json(path: Path, payload: dict) -> dict:
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    with gzip.open(path, "wb", 9) as f:
        f.write(raw)
    return {
        "path": str(path),
        "raw_bytes": len(raw),
        "gzip_bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def generate_degree() -> list[dict]:
    base = enumerate_base_sequences()
    records = []
    counts = {"stage1_farkas": 0, "stage2_farkas": 0, "survivor": 0}
    started = time.time()
    for index, (seq, triangles) in enumerate(base, 1):
        m1 = stage_model(seq, False)
        r1 = primal_solve(m1)
        if not r1.success:
            cert = find_farkas(m1)
            ok, msg = verify_farkas(m1, cert)
            if not ok:
                raise RuntimeError(msg)
            kind = "stage1_farkas"
            rec = {"sequence": list(seq), "triangles": triangles, "kind": kind, "cert": cert}
        else:
            m2 = stage_model(seq, True)
            r2 = primal_solve(m2)
            if not r2.success:
                cert = find_farkas(m2)
                ok, msg = verify_farkas(m2, cert)
                if not ok:
                    raise RuntimeError(msg)
                kind = "stage2_farkas"
                rec = {"sequence": list(seq), "triangles": triangles, "kind": kind, "cert": cert}
            else:
                kind = "survivor"
                rec = {"sequence": list(seq), "triangles": triangles, "kind": kind}
        counts[kind] += 1
        records.append(rec)
        if index % 100 == 0:
            print(json.dumps({"phase": "degree", "index": index, "counts": counts, "elapsed": time.time()-started}), flush=True)

    if counts != {"stage1_farkas": 1359, "stage2_farkas": 676, "survivor": 42}:
        raise RuntimeError(f"unexpected degree counts: {counts}")
    payload = {"format": "snn16-degree-reduction-v1", "base_count": 2077, "counts": counts, "records": records}
    info = write_gzip_json(CERTS / "degree_reduction.json.gz", payload)
    survivors = [
        {"index": i, "sequence": r["sequence"], "triangles": r["triangles"]}
        for i, r in enumerate((r for r in records if r["kind"] == "survivor"), 1)
    ]
    (DATA / "survivors42_exact.json").write_text(json.dumps(survivors, indent=2) + "\n")
    print(json.dumps({"phase": "degree_done", "counts": counts, **info}, sort_keys=True), flush=True)
    return survivors


def solve_tree(model):
    stats = {"nodes": 0, "leaves": 0, "maxdepth": 0, "branches": 0}
    edge_vars = {j for j, n in enumerate(model.names) if n.startswith("E[")}

    def rec(lo, hi, depth):
        stats["nodes"] += 1
        stats["maxdepth"] = max(stats["maxdepth"], depth)
        result = primal_solve(model, lo, hi, presolve=True)
        if not result.success:
            cert = find_farkas(model, lo, hi)
            ok, msg = verify_farkas(model, cert, lo, hi, True)
            if not ok:
                raise RuntimeError(msg)
            stats["leaves"] += 1
            return {"type": "leaf", "cert": cert}

        fractional = [j for j in model.integer if abs(result.x[j] - round(result.x[j])) > 1e-7]
        if not fractional:
            raise RuntimeError("integer-feasible class model found")
        preferred = [j for j in fractional if j in edge_vars]
        pool = preferred or fractional
        j = max(pool, key=lambda q: min(result.x[q]-math.floor(result.x[q]), math.ceil(result.x[q])-result.x[q]))
        floor = math.floor(result.x[j])
        left_hi = list(hi)
        left_hi[j] = floor if left_hi[j] is None else min(left_hi[j], floor)
        right_lo = list(lo)
        right_lo[j] = max(right_lo[j], floor + 1)
        stats["branches"] += 1
        left = rec(list(lo), left_hi, depth + 1)
        right = rec(right_lo, list(hi), depth + 1)
        return {"type": "branch", "var": j, "floor": floor, "left": left, "right": right}

    return rec(list(model.lo), list(model.hi), 0), stats


def generate_class(survivors: list[dict] | None = None) -> None:
    if survivors is None:
        survivors = json.loads((DATA / "survivors42_exact.json").read_text())
    items = []
    started = time.time()
    for item in survivors:
        model = class_model(tuple(item["sequence"]), item["triangles"])
        t0 = time.time()
        tree, stats = solve_tree(model)
        stats["elapsed_generate"] = time.time() - t0
        items.append({"index": item["index"], "sequence": item["sequence"], "triangles": item["triangles"], "stats": stats, "tree": tree})
        print(json.dumps({"phase": "class", "index": item["index"], **stats}), flush=True)
    payload = {"format": "snn16-class-exhaustion-v1", "count": len(items), "items": items}
    info = write_gzip_json(CERTS / "class_exhaustion.json.gz", payload)
    print(json.dumps({
        "phase": "class_done",
        "total_nodes": sum(x["stats"]["nodes"] for x in items),
        "total_leaves": sum(x["stats"]["leaves"] for x in items),
        "maxdepth": max(x["stats"]["maxdepth"] for x in items),
        "elapsed": time.time() - started,
        **info,
    }, sort_keys=True), flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", choices=["degree", "class", "all"], default="all")
    args = ap.parse_args()
    survivors = None
    if args.phase in ("degree", "all"):
        survivors = generate_degree()
    if args.phase in ("class", "all"):
        generate_class(survivors)


if __name__ == "__main__":
    main()
