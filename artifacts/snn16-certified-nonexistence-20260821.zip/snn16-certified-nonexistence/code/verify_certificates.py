#!/usr/bin/env python3
"""Strict independent exact verifier for the S_{16,16} nonexistence certificates.

Trusted computing base: Python 3 standard library only. The verifier
reconstructs every linear system from the mathematical definitions, checks all
rational Farkas identities using fractions.Fraction, and checks every integer
branch split. It deliberately uses explicit checks rather than ``assert``, so
verification remains active under ``python -O``.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction
from itertools import combinations_with_replacement
from math import comb
from pathlib import Path
import gzip
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DEG = ROOT / "certs" / "degree_reduction.json.gz"
CLS = ROOT / "certs" / "class_exhaustion.json.gz"


class VerificationError(RuntimeError):
    pass


def require(condition: bool, message: object) -> None:
    if not condition:
        raise VerificationError(str(message))


class VM:
    def __init__(self, names, eq, ub, lo, hi, integer):
        self.names = names
        self.eq = eq
        self.ub = ub
        self.lo = lo
        self.hi = hi
        self.integer = set(integer)

    def allub(self, lo=None, hi=None):
        lo = self.lo if lo is None else lo
        hi = self.hi if hi is None else hi
        rows = list(self.ub)
        for j, a in enumerate(lo):
            if a is not None:
                rows.append(({j: -1}, -a))
        for j, b in enumerate(hi):
            if b is not None:
                rows.append(({j: 1}, b))
        return rows


def erdos_gallai(seq):
    d = sorted(seq, reverse=True)
    p = [0]
    if sum(d) & 1:
        return False
    for x in d:
        p.append(p[-1] + x)
    return all(
        p[k] <= k * (k - 1) + sum(min(x, k) for x in d[k:])
        for k in range(1, len(d) + 1)
    )


def base_sequences():
    moment_count = graphical_count = 0
    out = []
    for s in combinations_with_replacement(range(2, 14), 16):
        if sum(s) != 120 or sum(x * x for x in s) != 1120:
            continue
        moment_count += 1
        if not erdos_gallai(s):
            continue
        graphical_count += 1
        q = sum(x**3 for x in s) - 11040
        if q % 6:
            continue
        t = q // 6
        if 54 <= t <= 166:
            out.append((s, t))
    return moment_count, graphical_count, out


def neighbor_sum_bounds(seq, d):
    z = list(seq)
    z.remove(d)
    z.sort()
    return sum(z[:d]), sum(z[len(z) - d :])


def stage_model(seq, third):
    cnt = Counter(seq)
    ds = sorted(cnt)
    names = []
    Y = {}
    for d in ds:
        for k in range(1, 16):
            Y[d, k] = len(names)
            names.append(("Y", d, k))
    S = {}
    if third:
        for d in ds:
            S[d] = len(names)
            names.append(("S", d))
    eq = []
    ub = []
    for d in ds:
        m = cnt[d]
        eq.append(({Y[d, k]: 1 for k in range(1, 16)}, 15 * m))
        eq.append(({Y[d, k]: k for k in range(1, 16)}, 16 * m * d))
        eq.append(({Y[d, k]: k * k for k in range(1, 16)}, 16 * m * (d * d + d)))
    for k in range(1, 16):
        eq.append(({Y[d, k]: 1 for d in ds}, 16))
    lo = [0] * len(names)
    hi = [None] * len(names)
    if third:
        for d in ds:
            m = cnt[d]
            b0 = d**3 + 2 * d**2
            y3 = {Y[d, k]: k**3 for k in range(1, 16)}
            j = S[d]
            a, b = neighbor_sum_bounds(seq, d)
            lo[j] = m * a
            hi[j] = m * b
            ub.append(({q: -coef for q, coef in y3.items()}, -16 * m * (b0 + d)))
            ub.append((dict(y3), 16 * m * (b0 + d * (16 - d))))
            r = dict(y3)
            r[j] = -16
            ub.append((r, 16 * m * b0))
            r = {q: -coef for q, coef in y3.items()}
            r[j] = 16
            ub.append((r, 32 * m * comb(d, 2) - 16 * m * b0))
            R = 120 - 2 * comb(15 - d, 2)
            r = {q: -coef for q, coef in y3.items()}
            r[j] = -16
            ub.append((r, -16 * m * (R + b0)))
            r = dict(y3)
            r[j] = 16
            ub.append((r, 16 * m * (120 + b0)))
        eq.append(({S[d]: 1 for d in ds}, 1120))
    return VM(names, eq, ub, lo, hi, [])


def triple_capacity(triple, cnt):
    z = Counter(triple)
    p = 1
    for d, r in z.items():
        if r > cnt[d]:
            return 0
        p *= comb(cnt[d], r)
    return p


def class_model(seq, target_triangles):
    cnt = Counter(seq)
    ds = sorted(cnt)
    names = []
    Y = {}
    for d in ds:
        for k in range(1, 16):
            Y[d, k] = len(names)
            names.append(("Y", d, k))
    pairs = []
    for ii in range(len(ds)):
        for jj in range(ii, len(ds)):
            pairs.append((ds[ii], ds[jj]))
    E = {}
    for pair in pairs:
        E[pair] = len(names)
        names.append(("E",) + pair)
    triples = [z for z in combinations_with_replacement(ds, 3) if triple_capacity(z, cnt)]
    T = {}
    for z in triples:
        T[z] = len(names)
        names.append(("T",) + z)
    C = {}
    for z in triples:
        C[z] = len(names)
        names.append(("C",) + z)

    eq = []
    ub = []

    # Spectral-weight row and column moments.
    for d in ds:
        m = cnt[d]
        eq.extend(
            [
                ({Y[d, k]: 1 for k in range(1, 16)}, 15 * m),
                ({Y[d, k]: k for k in range(1, 16)}, 16 * m * d),
                ({Y[d, k]: k * k for k in range(1, 16)}, 16 * m * (d * d + d)),
            ]
        )
    for k in range(1, 16):
        eq.append(({Y[d, k]: 1 for d in ds}, 16))

    # Degree-class stub equations in G.
    for d in ds:
        r = {}
        for a, b in pairs:
            if a == b == d:
                r[E[a, b]] = 2
            elif d == a or d == b:
                r[E[a, b]] = 1
        eq.append((r, cnt[d] * d))

    eq.append(({T[z]: 1 for z in triples}, target_triangles))
    eq.append(({C[z]: 1 for z in triples}, 220 - target_triangles))

    # Aggregated third diagonal moments in G.
    for d in ds:
        m = cnt[d]
        b0 = d**3 + 2 * d**2
        r = {Y[d, k]: k**3 for k in range(1, 16)}
        for a, b in pairs:
            q = 2 * d if a == b == d else (b if a == d else (a if b == d else 0))
            if q:
                r[E[a, b]] = r.get(E[a, b], 0) - 16 * q
        for z in triples:
            q = sum(1 for x in z if x == d)
            if q:
                r[T[z]] = r.get(T[z], 0) + 32 * q
        eq.append((r, 16 * m * b0))

    # Aggregated third diagonal moments in the complement.
    for d in ds:
        m = cnt[d]
        db = 15 - d
        b0 = db**3 + 2 * db**2
        r = {Y[d, 16 - k]: k**3 for k in range(1, 16)}
        const = 0
        for a, b in pairs:
            cap = comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
            q = 2 * (15 - d) if a == b == d else ((15 - b) if a == d else ((15 - a) if b == d else 0))
            if q:
                const += q * cap
                r[E[a, b]] = r.get(E[a, b], 0) + 16 * q
        for z in triples:
            q = sum(1 for x in z if x == d)
            if q:
                r[C[z]] = r.get(C[z], 0) + 32 * q
        eq.append((r, 16 * m * b0 + 16 * const))

    # Triangle incidences on each degree-pair edge class.
    for a, b in pairs:
        cap = comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
        rg = {}
        rc = {}
        for z in triples:
            cc = Counter(z)
            q = comb(cc[a], 2) if a == b else cc[a] * cc[b]
            if q:
                rg[T[z]] = q
                rc[C[z]] = q
        rg[E[a, b]] = rg.get(E[a, b], 0) - (min(a, b) - 1)
        ub.append((rg, 0))
        q = 14 - max(a, b)
        rc[E[a, b]] = rc.get(E[a, b], 0) + q
        ub.append((rc, q * cap))

    # Vertex-wedge bounds.
    for d in ds:
        rg = {}
        rc = {}
        for z in triples:
            q = sum(1 for x in z if x == d)
            if q:
                rg[T[z]] = q
                rc[C[z]] = q
        ub.append((rg, cnt[d] * comb(d, 2)))
        ub.append((rc, cnt[d] * comb(15 - d, 2)))

    lo = [0] * len(names)
    hi = [None] * len(names)
    integer = []
    for a, b in pairs:
        j = E[a, b]
        integer.append(j)
        hi[j] = comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
    for z in triples:
        q = triple_capacity(z, cnt)
        for D in (T, C):
            j = D[z]
            integer.append(j)
            hi[j] = q
    return VM(names, eq, ub, lo, hi, integer)


def rational(q):
    require(isinstance(q, list) and len(q) == 3, f"bad rational record {q!r}")
    den = int(q[2])
    require(den != 0, f"zero denominator {q!r}")
    return Fraction(int(q[1]), den)


def check_farkas(model, cert, lo=None, hi=None):
    require(isinstance(cert, dict) and set(cert) == {"y", "z"}, "bad Farkas certificate keys")
    ub = model.allub(lo, hi)
    lhs = [Fraction(0) for _ in model.names]
    rhs = Fraction(0)

    seen = set()
    for q in cert["y"]:
        i = int(q[0])
        v = rational(q)
        require(i not in seen, f"duplicate inequality multiplier index {i}")
        require(0 <= i < len(ub), f"inequality multiplier index out of range {i}")
        require(v >= 0, f"negative inequality multiplier at {i}: {v}")
        seen.add(i)
        row, b = ub[i]
        rhs += v * b
        for j, a in row.items():
            lhs[j] += v * a

    seen = set()
    for q in cert["z"]:
        i = int(q[0])
        v = rational(q)
        require(i not in seen, f"duplicate equality multiplier index {i}")
        require(0 <= i < len(model.eq), f"equality multiplier index out of range {i}")
        seen.add(i)
        row, b = model.eq[i]
        rhs += v * b
        for j, a in row.items():
            lhs[j] += v * a

    bad = next(((i, x) for i, x in enumerate(lhs) if x), None)
    require(bad is None, f"Farkas variable coefficients do not cancel: {bad}")
    require(rhs < 0, f"Farkas right-hand side is not negative: {rhs}")
    return rhs


def walk(model, node, lo, hi, depth=0):
    require(isinstance(node, dict) and "type" in node, "malformed branch-tree node")
    if node["type"] == "leaf":
        require(set(node) == {"type", "cert"}, "malformed leaf")
        check_farkas(model, node["cert"], lo, hi)
        return (1, 1, depth)

    require(node["type"] == "branch", f"unknown node type {node['type']!r}")
    require(set(node) == {"type", "var", "floor", "left", "right"}, "malformed branch")
    j = int(node["var"])
    a = int(node["floor"])
    require(j in model.integer, f"branch variable {j} is not integer-constrained")
    require(lo[j] is not None and lo[j] <= a, f"invalid branch lower bound at variable {j}")
    require(hi[j] is None or a < hi[j], f"invalid branch upper bound at variable {j}")

    left_hi = list(hi)
    left_hi[j] = a if left_hi[j] is None else min(left_hi[j], a)
    right_lo = list(lo)
    right_lo[j] = max(right_lo[j], a + 1)

    n1, l1, d1 = walk(model, node["left"], list(lo), left_hi, depth + 1)
    n2, l2, d2 = walk(model, node["right"], right_lo, list(hi), depth + 1)
    return 1 + n1 + n2, l1 + l2, max(d1, d2)


def verify():
    started = time.time()
    moment_count, graphical_count, base = base_sequences()
    require(
        (moment_count, graphical_count, len(base)) == (2249, 2233, 2077),
        (moment_count, graphical_count, len(base)),
    )

    with gzip.open(DEG, "rt", encoding="utf-8") as f:
        degree_data = json.load(f)
    require(degree_data.get("format") == "snn16-degree-reduction-v1", "bad degree certificate format")
    require(degree_data.get("base_count") == 2077, "bad degree base count")
    require(len(degree_data.get("records", [])) == 2077, "bad degree record count")

    survivors = []
    counts = Counter()
    for (seq, t), rec in zip(base, degree_data["records"]):
        require(rec.get("sequence") == list(seq), f"degree sequence record mismatch: {seq}")
        require(rec.get("triangles") == t, f"triangle record mismatch: {seq}")
        kind = rec.get("kind")
        counts[kind] += 1
        if kind == "stage1_farkas":
            check_farkas(stage_model(seq, False), rec["cert"])
        elif kind == "stage2_farkas":
            check_farkas(stage_model(seq, True), rec["cert"])
        elif kind == "survivor":
            require(set(rec) == {"sequence", "triangles", "kind"}, "survivor record has unexpected fields")
            survivors.append((seq, t))
        else:
            raise VerificationError(f"unknown degree record kind {kind!r}")

    expected_counts = {"stage1_farkas": 1359, "stage2_farkas": 676, "survivor": 42}
    require(dict(counts) == expected_counts, f"degree certificate counts {dict(counts)}")

    with gzip.open(CLS, "rt", encoding="utf-8") as f:
        class_data = json.load(f)
    require(class_data.get("format") == "snn16-class-exhaustion-v1", "bad class certificate format")
    require(class_data.get("count") == 42, "bad class count")
    require(len(class_data.get("items", [])) == 42, "bad class item count")

    total_nodes = 0
    total_leaves = 0
    max_depth = 0
    for index, ((seq, t), item) in enumerate(zip(survivors, class_data["items"]), 1):
        require(item.get("index") == index, f"class item index mismatch {index}")
        require(item.get("sequence") == list(seq), f"class item sequence mismatch {index}")
        require(item.get("triangles") == t, f"class item triangle mismatch {index}")
        model = class_model(seq, t)
        nodes, leaves, depth = walk(model, item["tree"], list(model.lo), list(model.hi))
        stats = item.get("stats", {})
        require(
            (nodes, leaves, depth) == (stats.get("nodes"), stats.get("leaves"), stats.get("maxdepth")),
            f"class item stats mismatch {index}: {(nodes, leaves, depth)} vs {stats}",
        )
        total_nodes += nodes
        total_leaves += leaves
        max_depth = max(max_depth, depth)

    return {
        "status": "VERIFIED_UNSAT",
        "moment_sequences": moment_count,
        "graphical_sequences": graphical_count,
        "base_sequences": len(base),
        "degree_certificate_counts": dict(counts),
        "class_models": 42,
        "tree_nodes": total_nodes,
        "branch_nodes": total_nodes - total_leaves,
        "farkas_leaves": total_leaves,
        "max_depth": max_depth,
        "degree_cert_sha256": hashlib.sha256(DEG.read_bytes()).hexdigest(),
        "class_cert_sha256": hashlib.sha256(CLS.read_bytes()).hexdigest(),
        "elapsed_seconds": round(time.time() - started, 6),
    }


def main() -> int:
    try:
        print(json.dumps(verify(), sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "VERIFICATION_FAILED", "error": str(exc)}, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
