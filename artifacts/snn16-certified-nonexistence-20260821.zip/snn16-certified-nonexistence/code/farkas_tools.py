#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
import math
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix
import sympy as sp
from exact_models import Model

def model_arrays(model:Model, lo=None, hi=None):
    ub=model.all_ub(lo,hi);eq=model.eq;n=model.nvar
    Aeq=lil_matrix((len(eq),n),dtype=float);beq=np.zeros(len(eq))
    for r,(row,b) in enumerate(eq):
        beq[r]=b
        for j,v in row.items():Aeq[r,j]=v
    Aub=lil_matrix((len(ub),n),dtype=float);bub=np.zeros(len(ub))
    for r,(row,b) in enumerate(ub):
        bub[r]=b
        for j,v in row.items():Aub[r,j]=v
    return Aub.tocsr(),bub,Aeq.tocsr(),beq,ub

def primal_solve(model:Model,lo=None,hi=None,presolve=True):
    Aub,bub,Aeq,beq,_=model_arrays(model,lo,hi)
    return linprog(np.zeros(model.nvar),A_ub=Aub,b_ub=bub,A_eq=Aeq,b_eq=beq,
                   bounds=[(None,None)]*model.nvar,method='highs',options={'presolve':presolve})

def verify_farkas(model:Model, cert:dict, lo=None, hi=None, verbose=False):
    ub=model.all_ub(lo,hi);eq=model.eq;n=model.nvar
    y={int(i):Fraction(int(a),int(b)) for i,a,b in cert['y']}
    z={int(i):Fraction(int(a),int(b)) for i,a,b in cert['z']}
    if any(v<0 for v in y.values()):return False,'negative y'
    lhs=[Fraction(0) for _ in range(n)];rhs=Fraction(0)
    for i,v in y.items():
        if not (0<=i<len(ub)):return False,'bad y index'
        row,b=ub[i];rhs+=v*b
        for j,a in row.items():lhs[j]+=v*a
    for i,v in z.items():
        if not (0<=i<len(eq)):return False,'bad z index'
        row,b=eq[i];rhs+=v*b
        for j,a in row.items():lhs[j]+=v*a
    if any(v!=0 for v in lhs):
        if verbose:
            bad=[(i,v) for i,v in enumerate(lhs) if v][:10]
            return False,f'nonzero lhs {bad}'
        return False,'nonzero lhs'
    if rhs>=0:return False,f'nonnegative rhs {rhs}'
    return True,str(rhs)

def _fraction_triplet(i,v:Fraction):
    return [int(i),int(v.numerator),int(v.denominator)]

def _reduce_conic_support(A, x, support, tol=1e-9):
    """Numerically reduce a positive conic representation to independent columns."""
    import scipy.linalg as la
    S=list(support); vals=np.array([x[i] for i in S],dtype=float)
    for _ in range(4*max(1,len(S))):
        M=A[:,S].toarray()
        rank=np.linalg.matrix_rank(M,tol=1e-9)
        if rank==len(S): return S,vals
        # right-null vector corresponding to smallest singular value
        u,sv,vh=np.linalg.svd(M,full_matrices=False)
        v=vh[-1]
        if np.max(v)<tol: v=-v
        pos=np.where(v>tol)[0]
        if len(pos)==0:
            v=-v;pos=np.where(v>tol)[0]
        alpha=np.min(vals[pos]/v[pos])
        vals=vals-alpha*v
        vals[np.abs(vals)<1e-8]=0
        keep=np.where(vals>1e-8)[0]
        S=[S[i] for i in keep];vals=vals[keep]
    return S,vals

def find_farkas(model:Model,lo=None,hi=None,tol=1e-8,denlim=10**9,debug=False):
    Aub,bub,Aeq,beq,ubrows=model_arrays(model,lo,hi)
    m=Aub.shape[0];q=Aeq.shape[0];n=model.nvar
    D=lil_matrix((n+1,m+2*q),dtype=float)
    D[:n,:m]=Aub.T
    D[:n,m:m+q]=Aeq.T
    D[:n,m+q:]=(-Aeq.T)
    D[n,:m]=bub
    D[n,m:m+q]=beq
    D[n,m+q:]=-beq
    D=D.tocsr()
    rhs=np.zeros(n+1);rhs[-1]=-1
    rng=np.random.default_rng((n*1000003+m*9176+q*37) & 0xffffffff)
    objectives=[np.ones(m+2*q),1.0+rng.random(m+2*q),1.0+rng.random(m+2*q)]
    last=''
    for attempt,c in enumerate(objectives):
        res=linprog(c,A_eq=D,b_eq=rhs,bounds=(0,None),method='highs-ds',options={'presolve':True})
        if not res.success:
            last=res.message;continue
        support=[i for i,v in enumerate(res.x) if v>tol]
        # cheap direct rational reconstruction
        vals={i:Fraction(float(res.x[i])).limit_denominator(denlim) for i in support}
        cert=_dual_values_to_cert(vals,m,q)
        ok,msg=verify_farkas(model,cert,lo,hi)
        if ok:return cert
        # Reduce to an independent conic support, then solve exactly.
        S,xred=_reduce_conic_support(D,res.x,support)
        Mfloat=D[:,S]
        rows=[[int(round(Mfloat[r,j])) for j in range(len(S))] for r in range(n+1)]
        M=sp.Matrix(rows);bvec=sp.Matrix([0]*n+[-1])
        try:
            solset=sp.linsolve((M,bvec))
            if solset is sp.EmptySet: continue
            sol=next(iter(solset))
            if any(v.free_symbols for v in sol):
                last='dependent exact support';continue
            vals={S[i]:Fraction(int(sp.numer(v)),int(sp.denom(v))) for i,v in enumerate(sol) if v!=0}
            if any(v<0 for v in vals.values()):
                last='negative exact basis';continue
            cert=_dual_values_to_cert(vals,m,q)
            ok,msg=verify_farkas(model,cert,lo,hi,True)
            if ok:return cert
            last=msg
        except Exception as e:
            last=repr(e)
    # final zero-objective retry; often gives a different BFS
    res=linprog(np.zeros(m+2*q),A_eq=D,b_eq=rhs,bounds=(0,None),method='highs-ds',options={'presolve':False})
    if res.success:
        support=[i for i,v in enumerate(res.x) if v>tol]
        S,xred=_reduce_conic_support(D,res.x,support)
        Mfloat=D[:,S]
        M=sp.Matrix([[int(round(Mfloat[r,j])) for j in range(len(S))] for r in range(n+1)])
        bvec=sp.Matrix([0]*n+[-1]);solset=sp.linsolve((M,bvec))
        if solset is not sp.EmptySet:
            sol=next(iter(solset))
            if not any(v.free_symbols for v in sol):
                vals={S[i]:Fraction(int(sp.numer(v)),int(sp.denom(v))) for i,v in enumerate(sol) if v!=0}
                cert=_dual_values_to_cert(vals,m,q);ok,msg=verify_farkas(model,cert,lo,hi,True)
                if ok:return cert
    raise RuntimeError('could not exactify Farkas certificate: '+last)

def _dual_values_to_cert(vals,m,q):
    y={};z={}
    for i,v in vals.items():
        if i<m:y[i]=y.get(i,Fraction(0))+v
        elif i<m+q:z[i-m]=z.get(i-m,Fraction(0))+v
        else:z[i-m-q]=z.get(i-m-q,Fraction(0))-v
    y={i:v for i,v in y.items() if v};z={i:v for i,v in z.items() if v}
    return {'y':[_fraction_triplet(i,v) for i,v in sorted(y.items())],
            'z':[_fraction_triplet(i,v) for i,v in sorted(z.items())]}
