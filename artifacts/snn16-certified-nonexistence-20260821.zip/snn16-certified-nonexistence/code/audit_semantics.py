#!/usr/bin/env python3
"""Adversarial semantic audit for the S_{16,16} certificate model.

This script does not solve the certificate LPs.  Instead it independently tests
all graph-to-model identities on deterministic random graphs, re-enumerates the
degree sequences via multiplicity recursion + Havel--Hakimi, checks complement
closure, and performs a certificate mutation test.

Trusted dependencies: Python 3 standard library only.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from math import comb
from pathlib import Path
import gzip
import importlib.util
import json
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
DEG_CERT = ROOT / "certs" / "degree_reduction.json.gz"
CLASS_CERT = ROOT / "certs" / "class_exhaustion.json.gz"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def enumerate_moment_sequences_independent() -> list[tuple[int, ...]]:
    """Enumerate via degree multiplicities, not combinations_with_replacement."""
    out: list[tuple[int, ...]] = []
    vals = list(range(2, 14))

    def rec(pos: int, nleft: int, sleft: int, qleft: int, counts: list[int]) -> None:
        if pos == len(vals):
            if nleft == sleft == qleft == 0:
                seq: list[int] = []
                for d, c in zip(vals, counts):
                    seq.extend([d] * c)
                out.append(tuple(seq))
            return
        d = vals[pos]
        # Simple exact bounds for pruning.
        if nleft < 0 or sleft < 0 or qleft < 0:
            return
        if pos == len(vals) - 1:
            c = nleft
            if sleft == c * d and qleft == c * d * d:
                rec(pos + 1, 0, 0, 0, counts + [c])
            return
        nxt = vals[pos + 1]
        hi = nleft
        for c in range(hi + 1):
            nn = nleft - c
            ss = sleft - c * d
            qq = qleft - c * d * d
            if ss < nn * nxt or ss > nn * 13:
                continue
            if qq < nn * nxt * nxt or qq > nn * 13 * 13:
                continue
            rec(pos + 1, nn, ss, qq, counts + [c])

    rec(0, 16, 120, 1120, [])
    out.sort()
    return out


def havel_hakimi_graphical(seq: tuple[int, ...]) -> bool:
    work = list(seq)
    while True:
        work = sorted((x for x in work if x), reverse=True)
        if not work:
            return True
        d = work.pop(0)
        if d < 0 or d > len(work):
            return False
        for i in range(d):
            work[i] -= 1
            if work[i] < 0:
                return False


def make_random_graph(rng: random.Random, p_num: int, p_den: int) -> list[list[int]]:
    n = 16
    A = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if rng.randrange(p_den) < p_num:
                A[i][j] = A[j][i] = 1
    return A


def matmul(A: list[list[int]], B: list[list[int]]) -> list[list[int]]:
    n = len(A)
    BT = list(zip(*B))
    return [[sum(x * y for x, y in zip(A[i], BT[j])) for j in range(n)] for i in range(n)]


def complement(A: list[list[int]]) -> list[list[int]]:
    n = len(A)
    return [[0 if i == j else 1 - A[i][j] for j in range(n)] for i in range(n)]


def triangle_data(A: list[list[int]]) -> tuple[int, list[int]]:
    n = len(A)
    local = [0] * n
    total = 0
    for i, j, k in combinations(range(n), 3):
        if A[i][j] and A[i][k] and A[j][k]:
            total += 1
            local[i] += 1
            local[j] += 1
            local[k] += 1
    return total, local


def audit_graph(A: list[list[int]]) -> None:
    n = len(A)
    d = [sum(row) for row in A]
    require(all(2 <= x <= 13 for x in d), "audit graph outside the certificate degree range")
    L = [[(d[i] if i == j else -A[i][j]) for j in range(n)] for i in range(n)]
    L2 = matmul(L, L)
    L3 = matmul(L2, L)
    t, tv = triangle_data(A)
    B = complement(A)
    db = [15 - x for x in d]
    tb, tbv = triangle_data(B)

    require(sum(d) % 2 == 0, "handshake parity")
    require(sum(L[i][i] for i in range(n)) == sum(d), "trace L")
    require(sum(L2[i][i] for i in range(n)) == sum(x * x + x for x in d), "trace L2")
    require(
        sum(L3[i][i] for i in range(n)) == sum(x**3 for x in d) + 3 * sum(x*x for x in d) - 6*t,
        "trace L3",
    )

    for v in range(n):
        s = sum(d[u] for u in range(n) if A[v][u])
        require(L2[v][v] == d[v] ** 2 + d[v], f"local L2 at {v}")
        require(L3[v][v] == d[v] ** 3 + 2*d[v]**2 + s - 2*tv[v], f"local L3 at {v}")
        h = s - 2*tv[v]
        require(h == d[v] + sum(A[u][w] for u in range(n) if A[v][u] for w in range(n) if (not A[v][w]) and w != v), f"h cut identity at {v}")
        require(d[v] <= h <= d[v] * (16 - d[v]), f"h bounds at {v}")
        C = comb(15 - d[v], 2)
        require(tbv[v] == C - (sum(d)//2) + s - tv[v], f"complement triangle identity at {v}")

    require(t + tb == comb(16, 3) - sum(d[i] * (15 - d[i]) for i in range(n)) // 2, "global complement triangle identity")

    # Degree-class edge and triangle statistics.
    cnt = Counter(d)
    ds = sorted(cnt)
    E: Counter[tuple[int, int]] = Counter()
    TG: Counter[tuple[int, int, int]] = Counter()
    TC: Counter[tuple[int, int, int]] = Counter()
    for i in range(n):
        for j in range(i + 1, n):
            key = tuple(sorted((d[i], d[j])))
            if A[i][j]:
                E[key] += 1
    for i, j, k in combinations(range(n), 3):
        key = tuple(sorted((d[i], d[j], d[k])))
        if A[i][j] and A[i][k] and A[j][k]:
            TG[key] += 1
        if B[i][j] and B[i][k] and B[j][k]:
            TC[key] += 1

    for a in ds:
        stubs = 0
        for b in ds:
            key = tuple(sorted((a, b)))
            stubs += (2 * E[key] if a == b else E[key])
        require(stubs == cnt[a] * a, f"class stub identity degree {a}")

        S_direct = sum(sum(d[u] for u in range(n) if A[v][u]) for v in range(n) if d[v] == a)
        S_from_E = 0
        for b in ds:
            key = tuple(sorted((a, b)))
            S_from_E += ((2*a) if a == b else b) * E[key]
        require(S_direct == S_from_E, f"class S identity degree {a}")

        T_direct = sum(tv[v] for v in range(n) if d[v] == a)
        T_from_types = sum(q.count(a) * c for q, c in TG.items())
        require(T_direct == T_from_types, f"class triangle incidence degree {a}")

        Sb_direct = sum(sum(db[u] for u in range(n) if B[v][u]) for v in range(n) if d[v] == a)
        Sb_from_E = 0
        for b in ds:
            key = tuple(sorted((a, b)))
            cap = comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
            Sb_from_E += ((2*(15-a)) if a == b else (15-b)) * (cap - E[key])
        require(Sb_direct == Sb_from_E, f"complement class S identity degree {a}")

        C_direct = sum(tbv[v] for v in range(n) if d[v] == a)
        C_from_types = sum(q.count(a) * c for q, c in TC.items())
        require(C_direct == C_from_types, f"complement triangle incidence degree {a}")

    for a in ds:
        for b in ds:
            if a > b:
                continue
            key = (a, b)
            cap = comb(cnt[a], 2) if a == b else cnt[a] * cnt[b]
            inc_g = 0
            inc_c = 0
            for q, c in TG.items():
                cc = Counter(q)
                mult = comb(cc[a], 2) if a == b else cc[a] * cc[b]
                inc_g += mult * c
            for q, c in TC.items():
                cc = Counter(q)
                mult = comb(cc[a], 2) if a == b else cc[a] * cc[b]
                inc_c += mult * c
            require(inc_g <= (min(a, b) - 1) * E[key], f"G edge-triangle bound {(a,b)}")
            require(inc_c <= (14 - max(a, b)) * (cap - E[key]), f"C edge-triangle bound {(a,b)}")


def load_verifier_module():
    path = ROOT / "code" / "verify_certificates.py"
    spec = importlib.util.spec_from_file_location("snn16_verify", path)
    require(spec is not None and spec.loader is not None, "cannot load verifier")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    # Independent sequence enumeration and graphicality test.
    moments = enumerate_moment_sequences_independent()
    require(len(moments) == 2249, f"independent moment count {len(moments)}")
    graphical = [s for s in moments if havel_hakimi_graphical(s)]
    require(len(graphical) == 2233, f"independent graphical count {len(graphical)}")
    base = []
    for s in graphical:
        q = sum(x**3 for x in s) - 11040
        if q % 6 == 0 and 54 <= q//6 <= 166:
            base.append((s, q//6))
    require(len(base) == 2077, f"independent base count {len(base)}")

    with gzip.open(DEG_CERT, "rt", encoding="utf-8") as f:
        degree_cert = json.load(f)
    cert_base = [(tuple(r["sequence"]), int(r["triangles"])) for r in degree_cert["records"]]
    require(cert_base == base, "degree certificate does not cover exactly the independent base list")
    survivors = [(tuple(r["sequence"]), int(r["triangles"])) for r in degree_cert["records"] if r["kind"] == "survivor"]
    require(len(survivors) == 42, "survivor count")

    with gzip.open(CLASS_CERT, "rt", encoding="utf-8") as f:
        class_cert = json.load(f)
    class_items = [(tuple(x["sequence"]), int(x["triangles"])) for x in class_cert["items"]]
    require(class_items == survivors, "class certificate does not cover exactly the survivors")

    survset = {s for s, _ in survivors}
    require(all(tuple(sorted(15-x for x in s)) in survset for s in survset), "survivors not complement closed")

    # Structured semantic tests before randomized testing.
    structured = []
    # C_16 and its complement.
    cyc = [[0] * 16 for _ in range(16)]
    for i in range(16):
        j = (i + 1) % 16
        cyc[i][j] = cyc[j][i] = 1
    structured.extend([cyc, complement(cyc)])
    # K_{8,8}.
    bip = [[0] * 16 for _ in range(16)]
    for i in range(8):
        for j in range(8, 16):
            bip[i][j] = bip[j][i] = 1
    structured.append(bip)
    # Complete 4-partite graph K_{4,4,4,4} and its complement 4K_4.
    mp = [[0] * 16 for _ in range(16)]
    for i in range(16):
        for j in range(i + 1, 16):
            if i // 4 != j // 4:
                mp[i][j] = mp[j][i] = 1
    structured.extend([mp, complement(mp)])
    for A in structured:
        audit_graph(A)

    # Deterministic semantic tests on random graphs whose degrees lie in [2,13].
    rng = random.Random(0x5161616)
    tested = 0
    attempts = 0
    while tested < 200 and attempts < 10000:
        attempts += 1
        p_num = 4 + (attempts % 5)  # p in {0.4,0.5,0.6,0.7,0.8}
        A = make_random_graph(rng, p_num, 10)
        d = [sum(row) for row in A]
        if not all(2 <= x <= 13 for x in d):
            continue
        audit_graph(A)
        tested += 1
    require(tested == 200, f"only tested {tested} semantic graphs")

    # Mutation test: a one-unit change in a genuine multiplier must be rejected.
    ver = load_verifier_module()
    first = next(r for r in degree_cert["records"] if r["kind"] == "stage1_farkas")
    cert = json.loads(json.dumps(first["cert"]))
    require(cert["y"], "empty certificate y support")
    cert["y"][0][1] += cert["y"][0][2]  # add exactly 1 to one nonnegative multiplier
    rejected = False
    try:
        ver.check_farkas(ver.stage_model(tuple(first["sequence"]), False), cert)
    except Exception:
        rejected = True
    require(rejected, "mutated Farkas certificate was not rejected")

    out = {
        "status": "SEMANTIC_AUDIT_PASSED",
        "moment_sequences_independent": len(moments),
        "graphical_sequences_havel_hakimi": len(graphical),
        "base_sequences": len(base),
        "survivors": len(survivors),
        "structured_graphs_tested": len(structured),
        "random_graphs_tested": tested,
        "mutation_rejected": rejected,
    }
    print(json.dumps(out, sort_keys=True))


if __name__ == "__main__":
    main()
