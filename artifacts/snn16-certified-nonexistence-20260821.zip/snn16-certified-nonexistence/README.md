# S_{16,16} certified nonexistence package

This package certifies that no simple graph on 16 vertices has Laplacian spectrum
`{0,1,...,15}`.

## Verify

```bash
./REPRODUCE.sh
```

Expected status lines:

- `"status": "VERIFIED_UNSAT"`
- `"status": "SEMANTIC_AUDIT_PASSED"`

The strict verifier needs only Python 3's standard library. Read `REPORT.md` for
the theorem, reduction, exact certificate semantics, audit, and scope.

## Contents

- `REPORT.md` — complete research report and proof description.
- `code/verify_certificates.py` — independent exact verifier.
- `code/audit_semantics.py` — separate semantic/adversarial audit.
- `certs/degree_reduction.json.gz` — 2,077-sequence Farkas reduction.
- `certs/class_exhaustion.json.gz` — 42 integer branch/Farkas trees.
- `data/survivors42_exact.json` — intermediate 42 degree sequences.
- `code/generate_certificates.py` — untrusted certificate generator.
- `MANIFEST.sha256` — fixed hashes for all release files.

## Result scope

The package resolves the `n=16` case only. It does not prove the general
`S_{n,n}` conjecture. The result is computer-assisted and has not yet undergone
external peer review.
