#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 code/verify_certificates.py
python3 code/audit_semantics.py
sha256sum -c MANIFEST.sha256
