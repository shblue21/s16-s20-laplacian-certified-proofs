# 16-vertex consecutive Laplacian spectrum: certified nonexistence

**Research date:** 2026-08-21  
**Result grade:** **SOLVED—CERTIFIED EXHAUSTION**  
**Theorem proved:** There is no simple undirected graph on 16 vertices whose Laplacian spectrum is exactly
\(\{0,1,2,\ldots,15\}\).

This is a computer-assisted proof with exact rational certificates and a separate standard-library verifier. It resolves only the \(n=16\) instance of the \(S_{n,n}\) conjecture. It does not prove the conjecture for all \(n\). The result and package have not undergone external peer review.

---

## 1. Result grade and one-sentence conclusion

**SOLVED—CERTIFIED EXHAUSTION.** Every possible degree sequence is covered, and every remaining degree-class model is eliminated by an exact branch-and-Farkas certificate; hence the required graph does not exist.

## 2. Why this grade is justified

The proof has three exhaustive layers.

1. Every target graph must have one of exactly **2,077** explicitly re-enumerated graphical degree sequences satisfying the first three spectral moments and the triangle/complement bounds.
2. Exact rational Farkas certificates eliminate **2,035** of those sequences using necessary spectral-weight and local third-moment linear systems, leaving exactly **42**.
3. For each of the 42, an integer degree-class edge/triangle model simultaneously encodes the graph and its complement. A complete branch tree on the integer class variables has exact rational Farkas certificates at every leaf. The 42 trees contain **174 nodes**, **66 branch nodes**, and **108 Farkas leaves**, with maximum depth **10**.

The independent verifier reconstructs all systems from definitions, verifies all **2,143** Farkas certificates over `fractions.Fraction`, and checks every integer branch split. Every Farkas contradiction is normalized to right-hand side exactly \(-1\). No floating-point result is trusted by the verifier.

## 3. Formal problem and latest public-literature status

Fallat, Kirkland, Molitierno and Neumann define
\[
S_{i,n}=\{0,1,\ldots,n\}\setminus\{i\}
\]
and conjecture that \(S_{n,n}=\{0,1,\ldots,n-1\}\) is not Laplacian-realizable for \(n\ge2\):

- S. M. Fallat, S. J. Kirkland, J. J. Molitierno, M. Neumann, *On Graphs whose Laplacian Matrices have Distinct Integer Eigenvalues*, J. Graph Theory 50 (2005), 162–174, DOI: <https://doi.org/10.1002/jgt.20102>.

Relevant later papers include:

- K. C. Das, S.-G. Lee, G.-S. Cheon, *On the conjecture for certain Laplacian integral spectrum of graphs*, J. Graph Theory 63 (2010), 106–113, DOI: <https://doi.org/10.1002/jgt.20412>.
- A. Goldberger, M. Neumann, *On a Conjecture on a Laplacian Matrix with Distinct Integral Spectrum*, J. Graph Theory 72 (2013), 178–208, DOI: <https://doi.org/10.1002/jgt.21638>.
- N. Johnston, S. Plosker, L. M. B. Varona, *Enumeration of Laplacian integral and \(\{-1,0,1\}\)-diagonalizable graphs*, arXiv:2607.06336v1, 7 July 2026, <https://arxiv.org/abs/2607.06336>.

The 2026 preprint proves the \(n=12\) case and states that \(n=16\) is then the smallest open case. On 2026-08-21 the arXiv record still displayed only v1, and targeted searches found no later public resolution. The proof below is independent of the older diameter, anti-Laplacian, refined-interlacing, and prime-order results; those results are background rather than trusted pruning rules in this certificate.

## 4. Newly established rigorous results

### 4.1 Spectral invariants, independently derived

Let the eigenvalues be \(0,1,\ldots,15\). Then
\[
\operatorname{tr}L=\sum_{k=0}^{15}k=120,
\qquad |E|=60,
\qquad \sum_v d_v=120.
\]
Also
\[
\operatorname{tr}L^2=\sum_{k=0}^{15}k^2=1240.
\]
Because \((L^2)_{vv}=d_v^2+d_v\),
\[
\sum_v d_v^2=1120.
\]
Furthermore
\[
\operatorname{tr}L^3=\sum_{k=0}^{15}k^3=14400.
\]
For a simple graph,
\[
\operatorname{tr}L^3=\sum_v d_v^3+3\sum_v d_v^2-6t,
\]
where \(t\) is the number of triangles. Hence
\[
\sum_v d_v^3-6t=11040.
\]
The zero eigenvalue is simple, so the graph is connected. For the complement,
\[
L(\overline G)=16I-J-L(G),
\]
and on \(\mathbf1^\perp\) the eigenvalue \(k\) is sent to \(16-k\). Thus the complement has the same spectrum and is also connected.

Matrix–Tree gives
\[
\tau(G)=\frac{1}{16}\prod_{k=1}^{15}k
       =\frac{15!}{16}
       =81{,}729{,}648{,}000.
\]
This value is checked but is not needed by the final exhaustion.

For every graph,
\[
t(G)+t(\overline G)
 =\binom{16}{3}-\frac12\sum_v d_v(15-d_v)
 =560-340=220.
\]
Also
\[
3t(G)\le\sum_v\binom{d_v}{2}=500,
\]
and the same bound holds for the complement. Therefore
\[
54\le t(G)\le166.
\]

### 4.2 A self-contained degree bound

Choose an orthonormal Laplacian eigenbasis \(u_0,u_1,\ldots,u_{15}\), with eigenvalue \(k\) for \(u_k\), and put
\[
w_{v,k}=u_k(v)^2.
\]
Connectedness gives \(u_0=\mathbf1/4\), so \(w_{v,0}=1/16\). The local first two moments are
\[
\sum_k k w_{v,k}=d_v,
\qquad
\sum_k k^2w_{v,k}=d_v^2+d_v.
\]
For \(1\le k\le15\),
\[
k^2\le16k-15
\]
because \((k-1)(15-k)\ge0\). Therefore
\[
d_v^2+d_v
 \le16d_v-15\sum_{k=1}^{15}w_{v,k}
 =16d_v-\frac{225}{16}.
\]
Thus
\[
16d_v^2-240d_v+225\le0,
\]
whose integer solutions are exactly
\[
2\le d_v\le13.
\]
This proves the stronger minimum/maximum degree restriction without importing an external theorem.

### 4.3 Exact degree-sequence reduction

Nondecreasing 16-tuples in \([2,13]\) were enumerated exactly.

| Stage | Exact count |
|---|---:|
| \(\sum d=120,\ \sum d^2=1120\) | 2,249 |
| Erdős–Gallai graphical | 2,233 |
| Integral \(t=(\sum d^3-11040)/6\) and \(54\le t\le166\) | 2,077 |
| Spectral-weight LP survives | 718 |
| Local-third-moment LP survives | 42 |
| Integer class model survives | 0 |

A separate audit re-enumerates the first line by degree multiplicities and tests graphicality by Havel–Hakimi, rather than reusing the verifier's combinations/Erdős–Gallai path. It obtains the same counts 2,249, 2,233, and 2,077.

## 5. Core proof and computation structure

### 5.1 Stage 1: degree-class spectral weights

For each occurring degree \(d\), let \(m_d\) be its multiplicity and define, for \(1\le k\le15\),
\[
Y_{d,k}=16\sum_{v:\,d_v=d} w_{v,k}.
\]
Every target graph supplies a nonnegative real solution of
\[
\sum_{k=1}^{15}Y_{d,k}=15m_d,
\]
\[
\sum_{k=1}^{15}kY_{d,k}=16m_d\,d,
\]
\[
\sum_{k=1}^{15}k^2Y_{d,k}=16m_d(d^2+d),
\]
and, for each \(k\),
\[
\sum_dY_{d,k}=16.
\]
These are only necessary conditions: no orthostochasticity or integral eigenvector hypothesis is imposed. Exact Farkas certificates show this system infeasible for 1,359 of the 2,077 sequences.

### 5.2 Stage 2: local third moments

For a vertex \(v\) of degree \(d\), define
\[
s_v=\sum_{u\sim v}d_u,
\qquad
q_v=\#\{\text{triangles containing }v\}.
\]
Direct multiplication gives
\[
(L^3)_{vv}=d^3+2d^2+s_v-2q_v.
\]
Put
\[
h_v=s_v-2q_v.
\]
If \(R_v=V\setminus(N(v)\cup\{v\})\), then
\[
h_v=d+e(N(v),R_v),
\]
so
\[
d\le h_v\le d(16-d).
\]
For a degree class, write
\[
S_d=\sum_{v:d_v=d}s_v,
\qquad H_d=\sum_{v:d_v=d}h_v.
\]
The spectral third moment gives
\[
\sum_{k=1}^{15}k^3Y_{d,k}
 =16\bigl[m_d(d^3+2d^2)+H_d\bigr].
\]
The graph supplies the following linear constraints.

- If \(\ell_d,u_d\) are the sums of the \(d\) smallest/largest degrees after deleting one occurrence of \(d\), then
  \[
  m_d\ell_d\le S_d\le m_du_d.
  \]
- Since \(H_d=S_d-2\sum q_v\),
  \[
  H_d\le S_d\le H_d+2m_d\binom d2.
  \]
- For each vertex,
  \[
  \overline q_v=\binom{15-d}{2}-60+s_v-q_v.
  \]
  The inequalities \(0\le\overline q_v\le\binom{15-d}{2}\) give
  \[
  m_d\!
  \left(120-2\binom{15-d}{2}\right)
  \le S_d+H_d\le120m_d.
  \]
- Finally,
  \[
  \sum_dS_d=\sum_vd_v^2=1120.
  \]

Exact Farkas certificates eliminate 676 of the 718 Stage-1 survivors. The remaining 42 sequences are listed in `data/survivors42_exact.json` and are closed under degree-complementation \(d\mapsto15-d\).

### 5.3 Final integer degree-class model

Fix one of the 42 sequences. Let \(D\) be its set of distinct degrees and
\[
P_{a,b}=\begin{cases}
\binom{m_a}{2},&a=b,\\
m_a m_b,&a<b.
\end{cases}
\]
The model has the following variables.

- The continuous spectral variables \(Y_{d,k}\) above.
- Integer \(E_{a,b}\): number of graph edges whose endpoint degrees are \(a,b\).
- Integer \(T_{a,b,c}\): number of graph triangles whose degree multiset is \(\{a,b,c\}\).
- Integer \(C_{a,b,c}\): the analogous complement-triangle count, still indexed by the original graph degrees.

All variables have their obvious nonnegative capacity bounds. The model imposes:

1. the Stage-1 spectral equations;
2. degree-class stub equations
   \[
   2E_{d,d}+\sum_{b\ne d}E_{\min(d,b),\max(d,b)}=m_d\,d;
   \]
3. total triangle equations
   \[
   \sum T_{a,b,c}=t,
   \qquad
   \sum C_{a,b,c}=220-t;
   \]
4. exact graph and complement classwise third-moment equations;
5. edge/triangle incidence bounds; for example, graph edges of class \((a,b)\) can lie in at most \(\min(a,b)-1\) triangles each, while complement edges can lie in at most \(14-\max(a,b)\);
6. graph and complement wedge bounds in each degree class.

For clarity, the classwise third-moment quantities are
\[
S_d^G=2dE_{d,d}+\sum_{b\ne d}bE_{\min(d,b),\max(d,b)},
\]
\[
R_d^G=\sum_{a\le b\le c}\nu_d(a,b,c)T_{a,b,c},
\]
where \(\nu_d\) is the multiplicity of \(d\) in the triple. Then
\[
\sum_{k=1}^{15}k^3Y_{d,k}
 =16\bigl[m_d(d^3+2d^2)+S_d^G-2R_d^G\bigr].
\]
For the complement, \(\overline E_{a,b}=P_{a,b}-E_{a,b}\), the complement degree of an original degree-\(d\) vertex is \(15-d\), and spectral weights obey
\[
\overline Y_{15-d,k}=Y_{d,16-k}.
\]
These give the corresponding exact complement third-moment equations.

Every actual target graph maps to an integer-feasible point of this model. The converse is not claimed: it is deliberately a relaxation. Therefore proving the relaxation integer-infeasible is sufficient for graph nonexistence.

### 5.4 Exact branch-and-Farkas certificate

At a branch-tree node, the model is
\[
Ax\le b,\qquad Cx=e,
\]
with additional current variable bounds. A leaf stores rational multipliers \(y,z\) satisfying
\[
y\ge0,
\qquad y^TA+z^TC=0,
\qquad y^Tb+z^Te=-1.
\]
If a feasible \(x\) existed, multiplying and adding the constraints would yield \(0\le-1\), a contradiction.

An internal node selects an integer variable \(x_j\) and an integer \(a\), and splits into
\[
x_j\le a
\qquad\text{or}\qquad
x_j\ge a+1.
\]
These cases are disjoint and cover every integer value in the parent interval. The exact verifier checks this coverage recursively.

No graph isomorphism reduction or symmetry-breaking rule is used. Consequently there is no symmetry-breaking soundness obligation.

## 6. Exact verification results

The strict verifier uses only the Python standard library and works in normal and optimized (`python -O`) mode. The recorded normal-mode output is:

```json
{"base_sequences": 2077, "branch_nodes": 66, "class_cert_sha256": "51cc5417f922f6bfceb3704c81a1691d813f76550517397269404b35225cc9bd", "class_models": 42, "degree_cert_sha256": "950d05274bf8e7234c0c72efa78927feeeacadc33ba5274f42c738ff3e8562c9", "degree_certificate_counts": {"stage1_farkas": 1359, "stage2_farkas": 676, "survivor": 42}, "elapsed_seconds": 5.378872, "farkas_leaves": 108, "graphical_sequences": 2233, "max_depth": 10, "moment_sequences": 2249, "status": "VERIFIED_UNSAT", "tree_nodes": 174}
```

Resource line from the same run:

```text
WALL=6.59 RSS=135040KB
```

The semantic/adversarial audit output is:

```json
{"base_sequences": 2077, "graphical_sequences_havel_hakimi": 2233, "moment_sequences_independent": 2249, "mutation_rejected": true, "random_graphs_tested": 200, "status": "SEMANTIC_AUDIT_PASSED", "structured_graphs_tested": 5, "survivors": 42}
```

The audit checks all local and complement identities on 5 structured and 200 deterministic random graphs, independently re-enumerates degree sequences, verifies exact survivor coverage, and confirms that a one-unit corruption of a genuine Farkas multiplier is rejected.

## 7. Code, data, certificates, and reproduction commands

### Trusted verification

From the package root:

```bash
./REPRODUCE.sh
```

Equivalent explicit commands:

```bash
python3 code/verify_certificates.py
python3 code/audit_semantics.py
sha256sum -c MANIFEST.sha256
```

The verifier requires only Python 3 standard-library modules.

### Certificate regeneration

Generation is not in the trusted base. It was performed with Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0/HiGHS, and SymPy 1.14.0:

```bash
python3 code/generate_certificates.py --phase all
python3 code/verify_certificates.py
```

Floating point is used only to discover LP bases and branch choices. Every emitted leaf is exactified and then independently checked over \(\mathbb Q\). Different solver versions may emit a different valid certificate tree and therefore different hashes.

### Certificate checksums

```text
950d05274bf8e7234c0c72efa78927feeeacadc33ba5274f42c738ff3e8562c9  certs/degree_reduction.json.gz
51cc5417f922f6bfceb3704c81a1691d813f76550517397269404b35225cc9bd  certs/class_exhaustion.json.gz
```

Compressed/raw sizes:

- `degree_reduction.json.gz`: 335,652 / 2,068,041 bytes.
- `class_exhaustion.json.gz`: 41,716 / 176,289 bytes.

## 8. Adversarial self-audit

The conclusion was attacked along the following lines.

### Dependency and circularity audit

The logical chain is one-way:

\[
\text{target spectrum}
\Rightarrow
\text{moments and degree bound}
\Rightarrow
\text{2,077 sequences}
\Rightarrow
\text{spectral-weight constraints}
\Rightarrow
\text{42 sequences}
\Rightarrow
\text{integer class models}
\Rightarrow
\text{exact infeasibility}.
\]

No later computational conclusion is used to justify an earlier reduction.

### Coverage audit

- Degree range \([2,13]\) is proved from the local spectral measure, not assumed.
- Sequence enumeration is repeated by an independent multiplicity recursion.
- Graphicality is cross-checked by Havel–Hakimi rather than Erdős–Gallai.
- Every one of the 2,077 records is matched in order to an independently re-enumerated sequence.
- The 42 class certificates match exactly the 42 surviving records.
- Every branch is on an explicitly integer-constrained variable and uses the exhaustive split \(x_j\le a\) / \(x_j\ge a+1\).

### Formula audit

Independent tests checked:

- \((L^2)_{vv}=d_v^2+d_v\);
- \((L^3)_{vv}=d_v^3+2d_v^2+s_v-2q_v\);
- \(h_v=d_v+e(N(v),R_v)\);
- the local complement-triangle formula;
- class stub and neighbor-degree identities;
- graph and complement edge/triangle incidence inequalities;
- complement degree and spectral mapping.

### Arithmetic and checker audit

- All Farkas arithmetic is exact rational arithmetic.
- The verifier rebuilds the systems rather than trusting matrices stored in the certificate.
- Every certificate gives exact contradiction \(-1\), not a floating tolerance.
- The checker uses explicit exceptions, so `python -O` does not disable validation.
- A deliberately mutated certificate is rejected.
- The compressed files are fixed by SHA-256 and a full-package manifest.

### Defects found during audit

An earlier draft verifier used Python `assert`, which can be disabled by `python -O`, and an early preliminary summary understated the maximum class-tree depth. The release verifier was rewritten with explicit checks and retested in optimized mode; the correct maximum depth is **10**. These corrections do not affect the mathematical certificate.

No remaining soundness defect was found in the final audit.

## 9. Exact remaining gap

For the stated \(n=16\) problem, no mathematical or certificate gap remains inside the supplied proof system: all necessary cases are certified infeasible.

What remains outside this result is:

- external replication and peer review;
- formalization in a proof assistant or translation to a more standard proof-certificate format;
- the general \(S_{n,n}\) conjecture for other unresolved orders.

Thus the correct scope is “the \(n=16\) instance is solved by certified exhaustion,” not “the general conjecture is proved.”

## 10. Highest-priority follow-up work

1. Independently reimplement the strict verifier in a second language or formal system and compare the fixed certificate hashes.
2. Compress the degree-class inequalities and their Farkas combinations into a human-readable analytic proof, especially the 42-sequence final stage.
3. Submit the theorem, complete certificate archive, and audit methodology for external review.
